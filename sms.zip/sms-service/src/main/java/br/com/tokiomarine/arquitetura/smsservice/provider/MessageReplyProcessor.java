package br.com.tokiomarine.arquitetura.smsservice.provider;

import java.util.List;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageReply;

public interface MessageReplyProcessor {

	void synchronize(MessageReply messageReply) throws Throwable;
	
	List<MessageReply> fetch() throws Throwable;

}
