package br.com.tokiomarine.arquitetura.smsservice.provider;

import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;

public class ProviderException extends Exception {

	private static final long serialVersionUID = 1L;

	private SmsServerErrors error;

	private Object resource;

	private Object details;

	public ProviderException(SmsServerErrors error, Object resource) {
		super();
		this.error = error;
		this.resource = resource;
	}

	public ProviderException(SmsServerErrors error, Object resource, Throwable cause) {
		super(cause);
		this.error = error;
		this.resource = resource;
	}

	public SmsServerErrors getError() {
		return error;
	}

	public Object getResource() {
		return resource;
	}

	public Object getDetails() {
		return details;
	}

}
