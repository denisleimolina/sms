package br.com.tokiomarine.arquitetura.smsservice.exception;

import org.springframework.http.HttpStatus;

public enum SmsServerErrors {
	VALIDATION_FAILED("A01", "Validation failed", HttpStatus.BAD_REQUEST),
	RESOURCE_NOT_FOUND("A02", "Resource not found", HttpStatus.NOT_FOUND),
	RESOURCE_ALREADY_EXISTS("A03", "The phone number is blacklisted", HttpStatus.CONFLICT),
	RESOURCE_IN_BLACKLIST("A04", "Resource in blacklist", HttpStatus.BAD_REQUEST),
	SERVICE_UNAVAILABLE("A05", "Service Unavailable", HttpStatus.SERVICE_UNAVAILABLE),
	SERVICE_UNAVAILABLE_PROVIDER("B01", "Service Unavailable in provider", HttpStatus.SERVICE_UNAVAILABLE),
	RESOURCE_NOT_FOUND_PROVIDER("B02", "Resource not found in provider", HttpStatus.NOT_FOUND),
	BAD_REQUEST_PROVIDER("B03", "Bad request in provider", HttpStatus.BAD_REQUEST);

	private String code;
	private String message;
	private HttpStatus status;

	private SmsServerErrors(String code, String message, HttpStatus status) {
		this.code = code;
		this.message = message;
		this.status = status;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	public HttpStatus getStatus() {
		return status;
	}

}
