package br.com.tokiomarine.arquitetura.smsservice.service;

import java.util.List;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.arquitetura.smsservice.domain.WebhookResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.WebhookProcessor;
import br.com.tokiomarine.arquitetura.smsservice.repository.WebhookRepository;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategyFactory;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class WebhookService extends AbstractCrudService<WebhookResponse, String> {

	private static final String PROCESSED = "processed";

	private static final String RECEIVED_AT = "receivedAt";

	private ProviderStrategyFactory strategyFactory;

	private MongoTemplate mongoTemplate;

	@Autowired
	public WebhookService(WebhookRepository repository, ProviderStrategyFactory strategyFactory,
			MongoTemplate mongoTemplate) {
		super(repository);
		this.strategyFactory = strategyFactory;
		this.mongoTemplate = mongoTemplate;
	}

	public void synchronizeMessageStatus(WebhookResponse webhookResponse) {
		try {
			final WebhookProcessor webhookProcessor = strategyFactory.getStrategy(WebhookProcessor.class,
					webhookResponse.getProvider());
			webhookProcessor.synchronize(webhookResponse);
		} catch (Throwable e) {
			log.error("Erro ao sincronizar o evento de webhook {} ", webhookResponse, e);
		}
	}

	public WebhookResponse findAndModifyByProcessed() {
		Criteria criteria = Criteria.where(PROCESSED).is(false);

		Query query = new Query().addCriteria(criteria).limit(1);

		Update update = new Update().set(PROCESSED, true);

		return mongoTemplate.findAndModify(query, update, WebhookResponse.class, WebhookResponse.COLLECTION_NAME);
	}

	public List<WebhookResponse> findAllAndRemoveByProcessed() {
		Criteria criteria = new Criteria();

		criteria.andOperator(Criteria.where(PROCESSED).is(true),
				Criteria.where(RECEIVED_AT).lte(LocalDateTime.now().minusMonths(3)));

		Query query = new Query().addCriteria(criteria);

		return mongoTemplate.findAllAndRemove(query, WebhookResponse.class);
	}

}
