package br.com.tokiomarine.arquitetura.smsservice.provider.twilio;

import org.springframework.beans.factory.annotation.Autowired;

import com.twilio.Twilio;
import com.twilio.exception.ApiException;
import com.twilio.type.PhoneNumber;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;
import br.com.tokiomarine.arquitetura.smsservice.provider.MessageSender;
import br.com.tokiomarine.arquitetura.smsservice.provider.ProviderException;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategy;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ProviderStrategy(name = Provider.TWILIO)
public class TwilioMessageSender implements MessageSender {

	private AppProperties properties;

	@Autowired
	public TwilioMessageSender(AppProperties properties) {
		this.properties = properties;
	}

	@Override
	public void send(Message message) throws ProviderException {
		log.info("[Twilio] Enviando mensagem {}...", message.getId());

		try {
			Twilio.init(properties.getTwilio().getUsername(), properties.getTwilio().getDefaultFrom());

			com.twilio.rest.api.v2010.account.Message twilioMessage = com.twilio.rest.api.v2010.account.Message
					.creator(new PhoneNumber(message.getTo()), new PhoneNumber(properties.getTwilio().getDefaultFrom()),
							message.getBody())
					.create();

			message.addTrace("createdMessage", twilioMessage.toString());
		} catch (ApiException e) {
			message.addTrace("createMessageError", e.getMessage());
			throw new ProviderException(SmsServerErrors.SERVICE_UNAVAILABLE, message, e);
		}
	}

	@Override
	public void synchronize(Message message) throws ProviderException {
	}

	@Override
	public void schedule(Message message) throws ProviderException {

	}

}
