package br.com.tokiomarine.arquitetura.smsservice.provider.tww;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.text.CharacterPredicates;
import org.apache.commons.text.RandomStringGenerator;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;
import br.com.tokiomarine.arquitetura.smsservice.provider.MessageSender;
import br.com.tokiomarine.arquitetura.smsservice.provider.ProviderException;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.client.SoapClient;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.mapper.TWWStatus;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMS;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMSAge;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMSAgeResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMSResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.StatusSMS;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.OutDataSet;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategy;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ProviderStrategy(name = Provider.TWW)
public class TWWMessageSender implements MessageSender {
	public static final String SUCCESS_RESPONSE = "OK";

	private SoapClient soapClient;

	private AppProperties properties;

	@Autowired
	public TWWMessageSender(SoapClient soapClient, AppProperties properties) {
		this.soapClient = soapClient;
		this.properties = properties;
	}

	@Override
	public void send(Message message) throws ProviderException {
		log.info("[TWW] Enviando mensagem {}...", message.getId());
		final String sincronizeKey = generateKey();

		try {
			EnviaSMS request = EnviaSMS.builder() // @formatter:off
					.numUsu(properties.getTww().getUsername()).senha(properties.getTww().getPassword())
					.seuNum(sincronizeKey)
					.celular(message.getTo())
					.mensagem(message.getBody())
					.build(); // @formatter:on

			message.addTrace("enviaSMSRequest", request.toString());

			EnviaSMSResponse response = soapClient.sendSMS(request);

			message.addTrace("enviaSMSResponse", response.toString());
			message.setSincronizeKey(sincronizeKey);

			if (!SUCCESS_RESPONSE.equals(response.getEnviaSMSResult())) {
				throw new TWWException(SmsServerErrors.BAD_REQUEST_PROVIDER);
			}
		} catch (TWWException e) {
			throw new ProviderException(e.getError(), message, e);
		} catch (Exception e) {
			message.addTrace("enviaSMSResponseError", e.getMessage());
			throw new ProviderException(SmsServerErrors.SERVICE_UNAVAILABLE, message, e);
		}

	}

	@Override
	public void synchronize(Message message) throws ProviderException {
		log.info("[TWW] Sincronizando mensagem {}...", message.getId());

		try {
			StatusSMS request = StatusSMS.builder() // @formatter:off
					.numUsu(properties.getTww().getUsername()).senha(properties.getTww().getPassword())
					.seuNum(message.getSincronizeKey())
					.build(); // @formatter:on

			message.addTrace("statusSMSRequest", request.toString());

			OutDataSet response = soapClient.statusSMS(request);

			message.addTrace("statusSMSResponse", response.toString());

			Optional<String> statusResponse = response.getFirstStatus();

			if (statusResponse.isPresent()) {
				String status = statusResponse.get();
				message.setStatus(TWWStatus.getStatus(status));
			}
		} catch (Exception e) {
			message.addTrace("statusSMSResponseError", e.getMessage());
			throw new ProviderException(SmsServerErrors.SERVICE_UNAVAILABLE, message, e);
		}
	}

	@Override
	public void schedule(Message message) throws ProviderException {
		log.info("[TWW] Enviando mensagem agendada {}...", message.getId());

		try {
			final String sincronizeKey = generateKey();
			XMLGregorianCalendar scheduledAt = parseDateTimeToXMLGregorianCalendar(message.getScheduledAt());

			EnviaSMSAge request = EnviaSMSAge.builder() // @formatter:off
					.numUsu(properties.getTww().getUsername()).senha(properties.getTww().getPassword())
					.seuNum(sincronizeKey)
					.celular(message.getTo())
					.mensagem(message.getBody())
					.agendamento(scheduledAt)
					.build(); // @formatter:onw

			message.addTrace("enviaSMSAgeRequest", request.toString());

			EnviaSMSAgeResponse response = soapClient.sendScheduledSMS(request);

			message.addTrace("enviaSMSAgeResponse", response.toString());
			message.setSincronizeKey(sincronizeKey);

			if (!SUCCESS_RESPONSE.equals(response.getEnviaSMSAgeResult())) {
				throw new TWWException(SmsServerErrors.BAD_REQUEST_PROVIDER);
			}
		} catch (TWWException e) {
			throw new ProviderException(e.getError(), message, e);
		} catch (Exception e) {
			message.addTrace("enviaSMSAgeResponseError", e.getMessage());
			throw new ProviderException(SmsServerErrors.SERVICE_UNAVAILABLE, message, e);
		}
	}

	private String generateKey() {
		RandomStringGenerator randomStringGenerator = new RandomStringGenerator.Builder().withinRange('0', 'z')
				.filteredBy(CharacterPredicates.LETTERS, CharacterPredicates.DIGITS).build();

		return randomStringGenerator.generate(20).toUpperCase();
	}

	private XMLGregorianCalendar parseDateTimeToXMLGregorianCalendar(LocalDateTime dateTime)
			throws DatatypeConfigurationException {
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(dateTime.format(DateTimeFormatter.ISO_DATE_TIME));
	}

}
