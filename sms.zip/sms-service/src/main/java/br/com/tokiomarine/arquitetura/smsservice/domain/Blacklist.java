package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.time.LocalDateTime;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import br.com.tokiomarine.arquitetura.smsservice.jackson.PhoneNumberDeserializer;
import lombok.Data;

@Data
@Document(collection = Blacklist.COLLECTION_NAME)
public class Blacklist {
	public static final String COLLECTION_NAME = "sms_blacklist";

	@Id
	@JsonIgnore
	private String id;

	@Indexed(unique = true)
	@NotEmpty
	@Size(min = 11)
	@JsonDeserialize(using = PhoneNumberDeserializer.class)
	private String number;

	@NotEmpty
	private String reason;

	@JsonProperty(access = Access.READ_ONLY)
	@DBRef
	private User createdBy;

	@JsonProperty(access = Access.READ_ONLY)
	private LocalDateTime createdAt;

}
