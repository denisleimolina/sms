package br.com.tokiomarine.arquitetura.smsservice.service.query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.arquitetura.smsservice.service.dto.BlacklistFilterDTO;

@Component
public class BlacklistQueryFactory {

	private static final String NUMBER = "number";

	@Autowired
	private CommonsQueryFactory commonsQueryFactory;

	public Query getQuery(BlacklistFilterDTO filters) {
		Query query = new Query();
		commonsQueryFactory.addCriteriaCreatedAt(query, filters.getCreatedAfterAt(), filters.getCreatedBeforeAt(),
				filters.getCreatedAt());
		commonsQueryFactory.addCriteria(query, NUMBER, filters.getNumber());

		return query;
	}

}
