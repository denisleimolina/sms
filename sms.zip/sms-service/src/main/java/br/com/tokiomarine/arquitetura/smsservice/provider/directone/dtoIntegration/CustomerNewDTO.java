package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration;

import java.util.ArrayList;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerNewDTO {
	
	private String id;
	private String name;
	private DocumentsDTO documentsDTO;
	private ArrayList<PhonesDTO> phonesDTO;
	
}
