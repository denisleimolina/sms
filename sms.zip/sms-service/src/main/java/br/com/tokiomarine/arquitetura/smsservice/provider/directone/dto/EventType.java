package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import com.fasterxml.jackson.annotation.JsonValue;

public enum EventType {
	PROCESSED(1, "Processed"), DROPPED(2, "Dropped"), BOUNCE(3, "Bounce"), SEND_TO_PROVIDER(4, "SentToProvider"),
	DELIVERED(5, "Delivered"), CLICK(6, "Click"), REPLY(7, "Reply");

	private int position;
	private String type;

	private EventType(int position, String type) {
		this.position = position;
		this.type = type;
	}

	public int getPosition() {
		return position;
	}

	@JsonValue
	public String getType() {
		return type;
	}

	
	
	public static EventType fromType(String value) {
		for (EventType event : EventType.values()) {
			if (event.getType().equals(value)) {
				return event;
			}
		}
		
		return null;
	}

}
