package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.builder;

import java.util.ArrayList;
import java.util.Arrays;

import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.CommunicationNewDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.CustomerNewDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.CustomersNewDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.DocumentsDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.PhonesDTO;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;




public class CommunicationBuilder {
	private static final String VAR_BODY = "var_body";
	private static final String PHONE_REGEX = "(\\d{2})(\\d{2})(\\d{5})(\\d+)";
	private static final String PHONE_REPLACEMENT = "+$1 ($2) $3-$4";
	private static final String ZONE_OFF_SET = "-03:00";
	
	private CommunicationNewDTO instance;
	
	public CommunicationBuilder() {
		this.instance = new CommunicationNewDTO();
	}
	
	public CommunicationBuilder withId(String id) {
		this.instance.setJourneyId(id);
		return this;
	}
	
	public CommunicationBuilder withCustomer(String phoneNumber, String body, String externalKey) {
		CustomersNewDTO customers = new CustomersNewDTO();
		customers.setCustomer(customers.getCustomer());
		customers.addVariable(VAR_BODY, body);
		customers.setExternalKey(externalKey);
		this.instance.getCustomers().add(customers);
		return this;
	}
	
	private CustomerNewDTO createCustomer(String phoneNumber, String name, DocumentsDTO doc) {
		CustomerNewDTO customer = new CustomerNewDTO();
		customer.setId(phoneNumber);
		customer.setName(name);
		customer.setDocumentsDTO(doc);
		customer.setPhonesDTO((ArrayList<PhonesDTO>) Arrays.asList(createPhone(phoneNumber)));
		return customer;
	}
	
	private PhonesDTO createPhone(String phoneNumber) {
		String formattedNumber = phoneNumber.replaceFirst(PHONE_REGEX, PHONE_REPLACEMENT);
		PhonesDTO phone = new PhonesDTO();
		phone.setFormattedNumber(formattedNumber);
		return phone;
	}

	public CommunicationNewDTO build() {
		return this.instance;
	}
	

	public static void main(String[] args) throws JsonProcessingException {
		CommunicationNewDTO com = new CommunicationNewDTO();
		com.setCustomer(new CustomerNewDTO());
		 ObjectMapper mapper = new ObjectMapper();
		 //Converting the Object to JSONString
	      String jsonString = mapper.writeValueAsString(com.toString());
	      System.out.println(jsonString);
	      
	      
	      
	}
	
}
