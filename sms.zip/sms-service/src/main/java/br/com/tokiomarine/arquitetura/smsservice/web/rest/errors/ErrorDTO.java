package br.com.tokiomarine.arquitetura.smsservice.web.rest.errors;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorDTO {

	@Builder.Default
	private LocalDateTime timestamp = LocalDateTime.now();

	private Integer status;

	private String error;

	@JsonInclude(Include.NON_EMPTY)
	private String code;

	private String message;

	@JsonInclude(Include.NON_EMPTY)
	private Serializable trace;

	private String path;

	@JsonInclude(Include.NON_EMPTY)
	private Object resource;

	@JsonInclude(Include.NON_EMPTY)
	private Map<String, Object> violations;

	public void addViolation(String key, Object value) {
		if (violations == null) {
			violations = new HashMap<>();
		}
		violations.put(key, value);
	}

	public static class ErrorDTOBuilder {

		public ErrorDTOBuilder httpStatus(HttpStatus httpStatus) {
			status = httpStatus.value();
			error = httpStatus.getReasonPhrase();
			return this;
		}

		public ErrorDTOBuilder serverError(SmsServerErrors error) {
			httpStatus(error.getStatus());
			code = error.getCode();
			message = error.getMessage();
			return this;
		}
	}
}
