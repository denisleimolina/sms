/**
 * Com esses serviços você pode enviar mensagens por CapCode para o sistema Reluz.
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "https://www.twwwireless.com.br/reluzcap/wsreluzcap", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl;
