package br.com.tokiomarine.arquitetura.smsservice.domain;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ResponseToken {

    private String Token;

}
