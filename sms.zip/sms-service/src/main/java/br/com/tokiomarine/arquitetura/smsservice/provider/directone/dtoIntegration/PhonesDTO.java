package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration;

import lombok.Data;

@Data
public class PhonesDTO {
	private String formattedNumber;
    private String number;
    private String kind;
	
}
