package br.com.tokiomarine.arquitetura.smsservice.provider.tww.client;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import org.w3c.dom.Node;

import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.BuscaSMSMONaoLido;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.BuscaSMSMONaoLidoResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMS;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMSAge;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMSAgeResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.EnviaSMSResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.StatusSMS;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.StatusSMSResponse;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.OutDataSet;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.OutDataSetMO;

public class SoapClient extends WebServiceGatewaySupport {

	public EnviaSMSResponse sendSMS(EnviaSMS request) {
		return (EnviaSMSResponse) getWebServiceTemplate().marshalSendAndReceive(request,
				new SoapActionCallback("https://www.twwwireless.com.br/reluzcap/wsreluzcap/EnviaSMS"));
	}

	public EnviaSMSAgeResponse sendScheduledSMS(EnviaSMSAge request) {
		return (EnviaSMSAgeResponse) getWebServiceTemplate().marshalSendAndReceive(request,
				new SoapActionCallback("https://www.twwwireless.com.br/reluzcap/wsreluzcap/EnviaSMSAge"));
	}

	public OutDataSet statusSMS(StatusSMS request) throws JAXBException {
		StatusSMSResponse statusSMSResponse = (StatusSMSResponse) getWebServiceTemplate().marshalSendAndReceive(request,
				new SoapActionCallback("https://www.twwwireless.com.br/reluzcap/wsreluzcap/StatusSMS"));

		if (statusSMSResponse.getStatusSMSResult() == null) {
			return new OutDataSet();
		}

		Node node = (Node) statusSMSResponse.getStatusSMSResult().getAny();

		if (node.getFirstChild() == null) {
			return new OutDataSet();
		}

		return parse(node, OutDataSet.class);
	}

	public OutDataSetMO searchSMS(BuscaSMSMONaoLido request) throws Exception {
		BuscaSMSMONaoLidoResponse response = (BuscaSMSMONaoLidoResponse) getWebServiceTemplate().marshalSendAndReceive(
				request,
				new SoapActionCallback("https://www.twwwireless.com.br/reluzcap/wsreluzcap/BuscaSMSMONaoLido"));

		Node node = (Node) response.getBuscaSMSMONaoLidoResult().getAny();

		if (node.getFirstChild() == null
				|| !node.getFirstChild().getNodeName().contains(OutDataSetMO.ROOT_ELEMENT)) {
			return new OutDataSetMO();
		}
		
		return parse(node, OutDataSetMO.class);
	}

	@SuppressWarnings("unchecked")
	private <T> T parse(Node node, Class<T> clazz) throws JAXBException {
		Unmarshaller unmarshaller = JAXBContext.newInstance(clazz).createUnmarshaller();
		return (T) unmarshaller.unmarshal(node.getFirstChild());
	}
}
