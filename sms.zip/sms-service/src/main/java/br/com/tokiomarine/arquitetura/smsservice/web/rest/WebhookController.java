package br.com.tokiomarine.arquitetura.smsservice.web.rest;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.domain.WebhookResponse;
import br.com.tokiomarine.arquitetura.smsservice.service.WebhookService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/v1/webhook")
public class WebhookController {

	@Autowired
	private WebhookService service;

	@Autowired
	public WebhookController(WebhookService service) {
		this.service = service;
	}

	@PostMapping("/{provider}")
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "", nickname = "createWebhook")
	public void create(@PathVariable Provider provider, @RequestBody Object response) throws Throwable {
		WebhookResponse webhookResponse = WebhookResponse.builder().provider(provider).response(response)
				.receivedAt(LocalDateTime.now()).build();

		service.save(webhookResponse);
	}

}