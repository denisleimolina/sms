package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.builder;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;

import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.CommunicationDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.CustomerDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.CustomersDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.KindDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.PhoneDTO;

public class CommunicationBuilder {
	private static final String VAR_BODY = "var_body";
	private static final String PHONE_REGEX = "(\\d{2})(\\d{2})(\\d{5})(\\d+)";
	private static final String PHONE_REPLACEMENT = "+$1 ($2) $3-$4";
	private static final String ZONE_OFF_SET = "-03:00";

	private CommunicationDTO instance;

	public CommunicationBuilder() {
		this.instance = new CommunicationDTO();
	}

	public CommunicationBuilder withId(String id) {
		this.instance.setCommunicationId(id);
		return this;
	}

	public CommunicationBuilder isTest(boolean isTest) {
		this.instance.setIsTest(isTest);
		return this;
	}

	public CommunicationBuilder scheduleAt(LocalDateTime scheduleAt) {
		this.instance.setScheduleDate(scheduleAt.atOffset(ZoneOffset.of(ZONE_OFF_SET)));
		return this;
	}

	public CommunicationBuilder withCustomer(String phoneNumber, String body, String externalKey) {
		CustomersDTO customers = new CustomersDTO();
		customers.setCustomer(createCustomer(phoneNumber));
		customers.setExternalKey(externalKey);
		customers.addVariable(VAR_BODY, body);

		this.instance.getCustomers().add(customers);
		return this;
	}

	private CustomerDTO createCustomer(String phoneNumber) {
		CustomerDTO customer = new CustomerDTO();
		customer.setIdentification(phoneNumber);
		customer.setName(phoneNumber);
		customer.setPhones(Arrays.asList(createPhone(phoneNumber)));

		return customer;
	}

	private PhoneDTO createPhone(String phoneNumber) {
		String formattedNumber = phoneNumber.replaceFirst(PHONE_REGEX, PHONE_REPLACEMENT);

		PhoneDTO phone = new PhoneDTO();
		phone.setFormattedNumber(formattedNumber);
		phone.setKind(new KindDTO("admin_cellphone"));

		return phone;
	}

	public CommunicationDTO build() {
		return this.instance;
	}

}
