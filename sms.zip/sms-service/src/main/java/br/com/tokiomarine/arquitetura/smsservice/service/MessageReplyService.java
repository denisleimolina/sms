package br.com.tokiomarine.arquitetura.smsservice.service;

import java.util.List;

import org.joda.time.LocalDateTime;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageReply;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.provider.MessageReplyProcessor;
import br.com.tokiomarine.arquitetura.smsservice.repository.MessageReplyRepository;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategyFactory;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MessageReplyService extends AbstractCrudService<MessageReply, String> {

	private static final String PROCESSED = "processed";

	private static final String CREATED_AT = "createdAt";

	private ProviderStrategyFactory strategyFactory;

	private MongoTemplate mongoTemplate;

	public MessageReplyService(MessageReplyRepository repository, ProviderStrategyFactory strategyFactory,
			MongoTemplate mongoTemplate) {
		super(repository);
		this.strategyFactory = strategyFactory;
		this.mongoTemplate = mongoTemplate;
	}

	public void fetchMessageReplies(Provider provider) {
		final MessageReplyProcessor messageReplyProcessor = strategyFactory.getStrategy(MessageReplyProcessor.class,
				provider);

		try {
			List<MessageReply> replies = messageReplyProcessor.fetch();
			save(replies);
		} catch (Throwable e) {
			log.error("[{}] Erro ao buscar mensagem de resposta: {} ", provider, e);
		}
	}

	public void synchronizeMessageReply(MessageReply reply) {
		final MessageReplyProcessor messageReplyProcessor = strategyFactory.getStrategy(MessageReplyProcessor.class,
				reply.getProvider());

		try {
			messageReplyProcessor.synchronize(reply);
		} catch (Throwable e) {
			log.error("[{}] Erro ao sincronizar mensagem de resposta: {} ", reply.getProvider(), e);
		}

	}

	public MessageReply findAndModifyByProcessed() {
		Criteria criteria = Criteria.where(PROCESSED).is(false);
		Query query = new Query().addCriteria(criteria).limit(1);
		Update update = new Update().set(PROCESSED, true);

		return mongoTemplate.findAndModify(query, update, MessageReply.class, MessageReply.COLLECTION_NAME);
	}

	public List<MessageReply> findAllAndRemoveByProcessed() {
		Criteria criteria = new Criteria();

		criteria.andOperator(Criteria.where(PROCESSED).is(true),
				Criteria.where(CREATED_AT).lte(LocalDateTime.now().minusMonths(3)));

		Query query = new Query().addCriteria(criteria);

		return mongoTemplate.findAllAndRemove(query, MessageReply.class);
	}

}
