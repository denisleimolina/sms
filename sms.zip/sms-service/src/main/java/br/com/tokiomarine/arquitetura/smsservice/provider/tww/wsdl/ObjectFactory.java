
package br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.com.twwwireless.sms package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _MaxExclusive_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "maxExclusive");
    private final static QName _Length_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "length");
    private final static QName _Boolean_QNAME = new QName("https://www.twwwireless.com.br/reluzcap/wsreluzcap", "boolean");
    private final static QName _FractionDigits_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "fractionDigits");
    private final static QName _All_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "all");
    private final static QName _MinInclusive_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "minInclusive");
    private final static QName _MinLength_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "minLength");
    private final static QName _DateTime_QNAME = new QName("https://www.twwwireless.com.br/reluzcap/wsreluzcap", "dateTime");
    private final static QName _DataSet_QNAME = new QName("https://www.twwwireless.com.br/reluzcap/wsreluzcap", "DataSet");
    private final static QName _Enumeration_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "enumeration");
    private final static QName _Choice_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "choice");
    private final static QName _String_QNAME = new QName("https://www.twwwireless.com.br/reluzcap/wsreluzcap", "string");
    private final static QName _MaxLength_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "maxLength");
    private final static QName _Key_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "key");
    private final static QName _Sequence_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "sequence");
    private final static QName _MaxInclusive_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "maxInclusive");
    private final static QName _MinExclusive_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "minExclusive");
    private final static QName _AnyAttribute_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "anyAttribute");
    private final static QName _Unique_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "unique");
    private final static QName _Int_QNAME = new QName("https://www.twwwireless.com.br/reluzcap/wsreluzcap", "int");
    private final static QName _GroupTypeElement_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "element");
    private final static QName _GroupTypeGroup_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "group");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.com.twwwireless.sms
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Element }
     * 
     */
    public Element createElement() {
        return new Element();
    }

    /**
     * Create an instance of {@link SimpleExplicitGroup }
     * 
     */
    public SimpleExplicitGroup createSimpleExplicitGroup() {
        return new SimpleExplicitGroup();
    }

    /**
     * Create an instance of {@link RealGroup }
     * 
     */
    public RealGroup createRealGroup() {
        return new RealGroup();
    }

    /**
     * Create an instance of {@link BuscaSMSAgendaDataSet.DS }
     * 
     */
    public BuscaSMSAgendaDataSet.DS createBuscaSMSAgendaDataSetDS() {
        return new BuscaSMSAgendaDataSet.DS();
    }

    /**
     * Create an instance of {@link EnviaSMSTemplateResponse }
     * 
     */
    public EnviaSMSTemplateResponse createEnviaSMSTemplateResponse() {
        return new EnviaSMSTemplateResponse();
    }

    /**
     * Create an instance of {@link EnviaSMS }
     * 
     */
    public EnviaSMS createEnviaSMS() {
        return new EnviaSMS();
    }

    /**
     * Create an instance of {@link Import }
     * 
     */
    public Import createImport() {
        return new Import();
    }

    /**
     * Create an instance of {@link StatusSMSResponse.StatusSMSResult }
     * 
     */
    public StatusSMSResponse.StatusSMSResult createStatusSMSResponseStatusSMSResult() {
        return new StatusSMSResponse.StatusSMSResult();
    }

    /**
     * Create an instance of {@link GroupRef }
     * 
     */
    public GroupRef createGroupRef() {
        return new GroupRef();
    }

    /**
     * Create an instance of {@link ResetaStatusLido }
     * 
     */
    public ResetaStatusLido createResetaStatusLido() {
        return new ResetaStatusLido();
    }

    /**
     * Create an instance of {@link BuscaSMSMONaoLidoResponse.BuscaSMSMONaoLidoResult }
     * 
     */
    public BuscaSMSMONaoLidoResponse.BuscaSMSMONaoLidoResult createBuscaSMSMONaoLidoResponseBuscaSMSMONaoLidoResult() {
        return new BuscaSMSMONaoLidoResponse.BuscaSMSMONaoLidoResult();
    }

    /**
     * Create an instance of {@link EnviaSMSTemplate }
     * 
     */
    public EnviaSMSTemplate createEnviaSMSTemplate() {
        return new EnviaSMSTemplate();
    }

    /**
     * Create an instance of {@link ComplexType }
     * 
     */
    public ComplexType createComplexType() {
        return new ComplexType();
    }

    /**
     * Create an instance of {@link BuscaSMSAgendaDataSetResponse.BuscaSMSAgendaDataSetResult }
     * 
     */
    public BuscaSMSAgendaDataSetResponse.BuscaSMSAgendaDataSetResult createBuscaSMSAgendaDataSetResponseBuscaSMSAgendaDataSetResult() {
        return new BuscaSMSAgendaDataSetResponse.BuscaSMSAgendaDataSetResult();
    }

    /**
     * Create an instance of {@link EnviaSMSAlt }
     * 
     */
    public EnviaSMSAlt createEnviaSMSAlt() {
        return new EnviaSMSAlt();
    }

    /**
     * Create an instance of {@link EnviaSMSAgeResponse }
     * 
     */
    public EnviaSMSAgeResponse createEnviaSMSAgeResponse() {
        return new EnviaSMSAgeResponse();
    }

    /**
     * Create an instance of {@link List }
     * 
     */
    public List createList() {
        return new List();
    }

    /**
     * Create an instance of {@link StatusSMSResponse }
     * 
     */
    public StatusSMSResponse createStatusSMSResponse() {
        return new StatusSMSResponse();
    }

    /**
     * Create an instance of {@link VerValidadeResponse }
     * 
     */
    public VerValidadeResponse createVerValidadeResponse() {
        return new VerValidadeResponse();
    }

    /**
     * Create an instance of {@link EnviaSMSAltResponse }
     * 
     */
    public EnviaSMSAltResponse createEnviaSMSAltResponse() {
        return new EnviaSMSAltResponse();
    }

    /**
     * Create an instance of {@link EnviaSMSAgeQuebraResponse }
     * 
     */
    public EnviaSMSAgeQuebraResponse createEnviaSMSAgeQuebraResponse() {
        return new EnviaSMSAgeQuebraResponse();
    }

    /**
     * Create an instance of {@link LocalElement }
     * 
     */
    public LocalElement createLocalElement() {
        return new LocalElement();
    }

    /**
     * Create an instance of {@link EnviaSMSTIMResponse.EnviaSMSTIMResult }
     * 
     */
    public EnviaSMSTIMResponse.EnviaSMSTIMResult createEnviaSMSTIMResponseEnviaSMSTIMResult() {
        return new EnviaSMSTIMResponse.EnviaSMSTIMResult();
    }

    /**
     * Create an instance of {@link BuscaSMS }
     * 
     */
    public BuscaSMS createBuscaSMS() {
        return new BuscaSMS();
    }

    /**
     * Create an instance of {@link EnviaSMS2SN }
     * 
     */
    public EnviaSMS2SN createEnviaSMS2SN() {
        return new EnviaSMS2SN();
    }

    /**
     * Create an instance of {@link SimpleExtensionType }
     * 
     */
    public SimpleExtensionType createSimpleExtensionType() {
        return new SimpleExtensionType();
    }

    /**
     * Create an instance of {@link BuscaSMSMOResponse }
     * 
     */
    public BuscaSMSMOResponse createBuscaSMSMOResponse() {
        return new BuscaSMSMOResponse();
    }

    /**
     * Create an instance of {@link EnviaSMSAge }
     * 
     */
    public EnviaSMSAge createEnviaSMSAge() {
        return new EnviaSMSAge();
    }

    /**
     * Create an instance of {@link EnviaSMSOTA8Bit }
     * 
     */
    public EnviaSMSOTA8Bit createEnviaSMSOTA8Bit() {
        return new EnviaSMSOTA8Bit();
    }

    /**
     * Create an instance of {@link Group }
     * 
     */
    public Group createGroup() {
        return new Group();
    }

    /**
     * Create an instance of {@link Annotated }
     * 
     */
    public Annotated createAnnotated() {
        return new Annotated();
    }

    /**
     * Create an instance of {@link ResetaMOLidoResponse }
     * 
     */
    public ResetaMOLidoResponse createResetaMOLidoResponse() {
        return new ResetaMOLidoResponse();
    }

    /**
     * Create an instance of {@link AttributeType }
     * 
     */
    public AttributeType createAttributeType() {
        return new AttributeType();
    }

    /**
     * Create an instance of {@link ComplexRestrictionType }
     * 
     */
    public ComplexRestrictionType createComplexRestrictionType() {
        return new ComplexRestrictionType();
    }

    /**
     * Create an instance of {@link VerCredito }
     * 
     */
    public VerCredito createVerCredito() {
        return new VerCredito();
    }

    /**
     * Create an instance of {@link ResetaStatusLidoResponse }
     * 
     */
    public ResetaStatusLidoResponse createResetaStatusLidoResponse() {
        return new ResetaStatusLidoResponse();
    }

    /**
     * Create an instance of {@link InsBLResponse }
     * 
     */
    public InsBLResponse createInsBLResponse() {
        return new InsBLResponse();
    }

    /**
     * Create an instance of {@link BuscaSMSMONaoLidoResponse }
     * 
     */
    public BuscaSMSMONaoLidoResponse createBuscaSMSMONaoLidoResponse() {
        return new BuscaSMSMONaoLidoResponse();
    }

    /**
     * Create an instance of {@link NarrowMaxMin }
     * 
     */
    public NarrowMaxMin createNarrowMaxMin() {
        return new NarrowMaxMin();
    }

    /**
     * Create an instance of {@link DataSet }
     * 
     */
    public DataSet createDataSet() {
        return new DataSet();
    }

    /**
     * Create an instance of {@link EnviaSMSXML }
     * 
     */
    public EnviaSMSXML createEnviaSMSXML() {
        return new EnviaSMSXML();
    }

    /**
     * Create an instance of {@link RestrictionType }
     * 
     */
    public RestrictionType createRestrictionType() {
        return new RestrictionType();
    }

    /**
     * Create an instance of {@link SimpleType }
     * 
     */
    public SimpleType createSimpleType() {
        return new SimpleType();
    }

    /**
     * Create an instance of {@link NoFixedFacet }
     * 
     */
    public NoFixedFacet createNoFixedFacet() {
        return new NoFixedFacet();
    }

    /**
     * Create an instance of {@link Appinfo }
     * 
     */
    public Appinfo createAppinfo() {
        return new Appinfo();
    }

    /**
     * Create an instance of {@link EnviaSMSTIMResponse }
     * 
     */
    public EnviaSMSTIMResponse createEnviaSMSTIMResponse() {
        return new EnviaSMSTIMResponse();
    }

    /**
     * Create an instance of {@link Keybase }
     * 
     */
    public Keybase createKeybase() {
        return new Keybase();
    }

    /**
     * Create an instance of {@link EnviaSMSDataSet.DS }
     * 
     */
    public EnviaSMSDataSet.DS createEnviaSMSDataSetDS() {
        return new EnviaSMSDataSet.DS();
    }

    /**
     * Create an instance of {@link Notation }
     * 
     */
    public Notation createNotation() {
        return new Notation();
    }

    /**
     * Create an instance of {@link InsBL }
     * 
     */
    public InsBL createInsBL() {
        return new InsBL();
    }

    /**
     * Create an instance of {@link LocalComplexType }
     * 
     */
    public LocalComplexType createLocalComplexType() {
        return new LocalComplexType();
    }

    /**
     * Create an instance of {@link BuscaSMSResponse.BuscaSMSResult }
     * 
     */
    public BuscaSMSResponse.BuscaSMSResult createBuscaSMSResponseBuscaSMSResult() {
        return new BuscaSMSResponse.BuscaSMSResult();
    }

    /**
     * Create an instance of {@link Redefine }
     * 
     */
    public Redefine createRedefine() {
        return new Redefine();
    }

    /**
     * Create an instance of {@link StatusSMS2SN }
     * 
     */
    public StatusSMS2SN createStatusSMS2SN() {
        return new StatusSMS2SN();
    }

    /**
     * Create an instance of {@link EnviaSMSXMLResponse }
     * 
     */
    public EnviaSMSXMLResponse createEnviaSMSXMLResponse() {
        return new EnviaSMSXMLResponse();
    }

    /**
     * Create an instance of {@link StatusSMSDataSet.DS }
     * 
     */
    public StatusSMSDataSet.DS createStatusSMSDataSetDS() {
        return new StatusSMSDataSet.DS();
    }

    /**
     * Create an instance of {@link BuscaSMSAgendaResponse }
     * 
     */
    public BuscaSMSAgendaResponse createBuscaSMSAgendaResponse() {
        return new BuscaSMSAgendaResponse();
    }

    /**
     * Create an instance of {@link VerBLResponse }
     * 
     */
    public VerBLResponse createVerBLResponse() {
        return new VerBLResponse();
    }

    /**
     * Create an instance of {@link VerCreditoResponse }
     * 
     */
    public VerCreditoResponse createVerCreditoResponse() {
        return new VerCreditoResponse();
    }

    /**
     * Create an instance of {@link Annotation }
     * 
     */
    public Annotation createAnnotation() {
        return new Annotation();
    }

    /**
     * Create an instance of {@link ExplicitGroup }
     * 
     */
    public ExplicitGroup createExplicitGroup() {
        return new ExplicitGroup();
    }

    /**
     * Create an instance of {@link DelSMSAgendaResponse }
     * 
     */
    public DelSMSAgendaResponse createDelSMSAgendaResponse() {
        return new DelSMSAgendaResponse();
    }

    /**
     * Create an instance of {@link BuscaSMSResponse }
     * 
     */
    public BuscaSMSResponse createBuscaSMSResponse() {
        return new BuscaSMSResponse();
    }

    /**
     * Create an instance of {@link BuscaSMSAgendaDataSetResponse }
     * 
     */
    public BuscaSMSAgendaDataSetResponse createBuscaSMSAgendaDataSetResponse() {
        return new BuscaSMSAgendaDataSetResponse();
    }

    /**
     * Create an instance of {@link AlteraSenhaResponse }
     * 
     */
    public AlteraSenhaResponse createAlteraSenhaResponse() {
        return new AlteraSenhaResponse();
    }

    /**
     * Create an instance of {@link ExtensionType }
     * 
     */
    public ExtensionType createExtensionType() {
        return new ExtensionType();
    }

    /**
     * Create an instance of {@link DelSMSAgenda }
     * 
     */
    public DelSMSAgenda createDelSMSAgenda() {
        return new DelSMSAgenda();
    }

    /**
     * Create an instance of {@link VerBLResponse.VerBLResult }
     * 
     */
    public VerBLResponse.VerBLResult createVerBLResponseVerBLResult() {
        return new VerBLResponse.VerBLResult();
    }

    /**
     * Create an instance of {@link BuscaSMSAgendaDataSet }
     * 
     */
    public BuscaSMSAgendaDataSet createBuscaSMSAgendaDataSet() {
        return new BuscaSMSAgendaDataSet();
    }

    /**
     * Create an instance of {@link EnviaSMSDataSet }
     * 
     */
    public EnviaSMSDataSet createEnviaSMSDataSet() {
        return new EnviaSMSDataSet();
    }

    /**
     * Create an instance of {@link EnviaSMSQuebra }
     * 
     */
    public EnviaSMSQuebra createEnviaSMSQuebra() {
        return new EnviaSMSQuebra();
    }

    /**
     * Create an instance of {@link Documentation }
     * 
     */
    public Documentation createDocumentation() {
        return new Documentation();
    }

    /**
     * Create an instance of {@link Attribute }
     * 
     */
    public Attribute createAttribute() {
        return new Attribute();
    }

    /**
     * Create an instance of {@link AlteraSenha }
     * 
     */
    public AlteraSenha createAlteraSenha() {
        return new AlteraSenha();
    }

    /**
     * Create an instance of {@link AttributeGroupRef }
     * 
     */
    public AttributeGroupRef createAttributeGroupRef() {
        return new AttributeGroupRef();
    }

    /**
     * Create an instance of {@link EnviaSMSConcatenadoComAcentoResponse }
     * 
     */
    public EnviaSMSConcatenadoComAcentoResponse createEnviaSMSConcatenadoComAcentoResponse() {
        return new EnviaSMSConcatenadoComAcentoResponse();
    }

    /**
     * Create an instance of {@link StatusSMSDataSet }
     * 
     */
    public StatusSMSDataSet createStatusSMSDataSet() {
        return new StatusSMSDataSet();
    }

    /**
     * Create an instance of {@link StatusSMS2SNResponse.StatusSMS2SNResult }
     * 
     */
    public StatusSMS2SNResponse.StatusSMS2SNResult createStatusSMS2SNResponseStatusSMS2SNResult() {
        return new StatusSMS2SNResponse.StatusSMS2SNResult();
    }

    /**
     * Create an instance of {@link Schema }
     * 
     */
    public Schema createSchema() {
        return new Schema();
    }

    /**
     * Create an instance of {@link Include }
     * 
     */
    public Include createInclude() {
        return new Include();
    }

    /**
     * Create an instance of {@link VerValidade }
     * 
     */
    public VerValidade createVerValidade() {
        return new VerValidade();
    }

    /**
     * Create an instance of {@link BuscaSMSMOResponse.BuscaSMSMOResult }
     * 
     */
    public BuscaSMSMOResponse.BuscaSMSMOResult createBuscaSMSMOResponseBuscaSMSMOResult() {
        return new BuscaSMSMOResponse.BuscaSMSMOResult();
    }

    /**
     * Create an instance of {@link BuscaSMSAgenda }
     * 
     */
    public BuscaSMSAgenda createBuscaSMSAgenda() {
        return new BuscaSMSAgenda();
    }

    /**
     * Create an instance of {@link StatusSMSNaoLido }
     * 
     */
    public StatusSMSNaoLido createStatusSMSNaoLido() {
        return new StatusSMSNaoLido();
    }

    /**
     * Create an instance of {@link LocalSimpleType }
     * 
     */
    public LocalSimpleType createLocalSimpleType() {
        return new LocalSimpleType();
    }

    /**
     * Create an instance of {@link Pattern }
     * 
     */
    public Pattern createPattern() {
        return new Pattern();
    }

    /**
     * Create an instance of {@link Facet }
     * 
     */
    public Facet createFacet() {
        return new Facet();
    }

    /**
     * Create an instance of {@link ResetaMOLido }
     * 
     */
    public ResetaMOLido createResetaMOLido() {
        return new ResetaMOLido();
    }

    /**
     * Create an instance of {@link StatusSMSDataSetResponse.StatusSMSDataSetResult }
     * 
     */
    public StatusSMSDataSetResponse.StatusSMSDataSetResult createStatusSMSDataSetResponseStatusSMSDataSetResult() {
        return new StatusSMSDataSetResponse.StatusSMSDataSetResult();
    }

    /**
     * Create an instance of {@link EnviaSMSConcatenadoSemAcento }
     * 
     */
    public EnviaSMSConcatenadoSemAcento createEnviaSMSConcatenadoSemAcento() {
        return new EnviaSMSConcatenadoSemAcento();
    }

    /**
     * Create an instance of {@link EnviaSMS2SNResponse }
     * 
     */
    public EnviaSMS2SNResponse createEnviaSMS2SNResponse() {
        return new EnviaSMS2SNResponse();
    }

    /**
     * Create an instance of {@link BuscaSMSMO }
     * 
     */
    public BuscaSMSMO createBuscaSMSMO() {
        return new BuscaSMSMO();
    }

    /**
     * Create an instance of {@link EnviaSMSDataSetResponse }
     * 
     */
    public EnviaSMSDataSetResponse createEnviaSMSDataSetResponse() {
        return new EnviaSMSDataSetResponse();
    }

    /**
     * Create an instance of {@link StatusSMS2SNResponse }
     * 
     */
    public StatusSMS2SNResponse createStatusSMS2SNResponse() {
        return new StatusSMS2SNResponse();
    }

    /**
     * Create an instance of {@link EnviaSMSQuebraResponse }
     * 
     */
    public EnviaSMSQuebraResponse createEnviaSMSQuebraResponse() {
        return new EnviaSMSQuebraResponse();
    }

    /**
     * Create an instance of {@link Restriction }
     * 
     */
    public Restriction createRestriction() {
        return new Restriction();
    }

    /**
     * Create an instance of {@link EnviaSMSOTA8BitResponse }
     * 
     */
    public EnviaSMSOTA8BitResponse createEnviaSMSOTA8BitResponse() {
        return new EnviaSMSOTA8BitResponse();
    }

    /**
     * Create an instance of {@link EnviaSMSESMDCS }
     * 
     */
    public EnviaSMSESMDCS createEnviaSMSESMDCS() {
        return new EnviaSMSESMDCS();
    }

    /**
     * Create an instance of {@link ComplexContent }
     * 
     */
    public ComplexContent createComplexContent() {
        return new ComplexContent();
    }

    /**
     * Create an instance of {@link BuscaSMSAgendaResponse.BuscaSMSAgendaResult }
     * 
     */
    public BuscaSMSAgendaResponse.BuscaSMSAgendaResult createBuscaSMSAgendaResponseBuscaSMSAgendaResult() {
        return new BuscaSMSAgendaResponse.BuscaSMSAgendaResult();
    }

    /**
     * Create an instance of {@link Wildcard }
     * 
     */
    public Wildcard createWildcard() {
        return new Wildcard();
    }

    /**
     * Create an instance of {@link EnviaSMSESMDCSResponse }
     * 
     */
    public EnviaSMSESMDCSResponse createEnviaSMSESMDCSResponse() {
        return new EnviaSMSESMDCSResponse();
    }

    /**
     * Create an instance of {@link StatusSMSNaoLidoResponse.StatusSMSNaoLidoResult }
     * 
     */
    public StatusSMSNaoLidoResponse.StatusSMSNaoLidoResult createStatusSMSNaoLidoResponseStatusSMSNaoLidoResult() {
        return new StatusSMSNaoLidoResponse.StatusSMSNaoLidoResult();
    }

    /**
     * Create an instance of {@link Union }
     * 
     */
    public Union createUnion() {
        return new Union();
    }

    /**
     * Create an instance of {@link TotalDigits }
     * 
     */
    public TotalDigits createTotalDigits() {
        return new TotalDigits();
    }

    /**
     * Create an instance of {@link SimpleContent }
     * 
     */
    public SimpleContent createSimpleContent() {
        return new SimpleContent();
    }

    /**
     * Create an instance of {@link EnviaSMSTIM }
     * 
     */
    public EnviaSMSTIM createEnviaSMSTIM() {
        return new EnviaSMSTIM();
    }

    /**
     * Create an instance of {@link WhiteSpace }
     * 
     */
    public WhiteSpace createWhiteSpace() {
        return new WhiteSpace();
    }

    /**
     * Create an instance of {@link Field }
     * 
     */
    public Field createField() {
        return new Field();
    }

    /**
     * Create an instance of {@link StatusSMSDataSetResponse }
     * 
     */
    public StatusSMSDataSetResponse createStatusSMSDataSetResponse() {
        return new StatusSMSDataSetResponse();
    }

    /**
     * Create an instance of {@link StatusSMS }
     * 
     */
    public StatusSMS createStatusSMS() {
        return new StatusSMS();
    }

    /**
     * Create an instance of {@link BuscaSMSMONaoLido }
     * 
     */
    public BuscaSMSMONaoLido createBuscaSMSMONaoLido() {
        return new BuscaSMSMONaoLido();
    }

    /**
     * Create an instance of {@link Selector }
     * 
     */
    public Selector createSelector() {
        return new Selector();
    }

    /**
     * Create an instance of {@link EnviaSMSResponse }
     * 
     */
    public EnviaSMSResponse createEnviaSMSResponse() {
        return new EnviaSMSResponse();
    }

    /**
     * Create an instance of {@link All }
     * 
     */
    public All createAll() {
        return new All();
    }

    /**
     * Create an instance of {@link Keyref }
     * 
     */
    public Keyref createKeyref() {
        return new Keyref();
    }

    /**
     * Create an instance of {@link EnviaSMSAgeQuebra }
     * 
     */
    public EnviaSMSAgeQuebra createEnviaSMSAgeQuebra() {
        return new EnviaSMSAgeQuebra();
    }

    /**
     * Create an instance of {@link OpenAttrs }
     * 
     */
    public OpenAttrs createOpenAttrs() {
        return new OpenAttrs();
    }

    /**
     * Create an instance of {@link AttributeGroup }
     * 
     */
    public AttributeGroup createAttributeGroup() {
        return new AttributeGroup();
    }

    /**
     * Create an instance of {@link NumFacet }
     * 
     */
    public NumFacet createNumFacet() {
        return new NumFacet();
    }

    /**
     * Create an instance of {@link StatusSMSNaoLidoResponse }
     * 
     */
    public StatusSMSNaoLidoResponse createStatusSMSNaoLidoResponse() {
        return new StatusSMSNaoLidoResponse();
    }

    /**
     * Create an instance of {@link Any }
     * 
     */
    public Any createAny() {
        return new Any();
    }

    /**
     * Create an instance of {@link SimpleRestrictionType }
     * 
     */
    public SimpleRestrictionType createSimpleRestrictionType() {
        return new SimpleRestrictionType();
    }

    /**
     * Create an instance of {@link EnviaSMSConcatenadoComAcento }
     * 
     */
    public EnviaSMSConcatenadoComAcento createEnviaSMSConcatenadoComAcento() {
        return new EnviaSMSConcatenadoComAcento();
    }

    /**
     * Create an instance of {@link EnviaSMSConcatenadoSemAcentoResponse }
     * 
     */
    public EnviaSMSConcatenadoSemAcentoResponse createEnviaSMSConcatenadoSemAcentoResponse() {
        return new EnviaSMSConcatenadoSemAcentoResponse();
    }

    /**
     * Create an instance of {@link VerBL }
     * 
     */
    public VerBL createVerBL() {
        return new VerBL();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Facet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "maxExclusive")
    public JAXBElement<Facet> createMaxExclusive(Facet value) {
        return new JAXBElement<Facet>(_MaxExclusive_QNAME, Facet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumFacet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "length")
    public JAXBElement<NumFacet> createLength(NumFacet value) {
        return new JAXBElement<NumFacet>(_Length_QNAME, NumFacet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://www.twwwireless.com.br/reluzcap/wsreluzcap", name = "boolean")
    public JAXBElement<Boolean> createBoolean(Boolean value) {
        return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumFacet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "fractionDigits")
    public JAXBElement<NumFacet> createFractionDigits(NumFacet value) {
        return new JAXBElement<NumFacet>(_FractionDigits_QNAME, NumFacet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link All }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "all")
    public JAXBElement<All> createAll(All value) {
        return new JAXBElement<All>(_All_QNAME, All.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Facet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "minInclusive")
    public JAXBElement<Facet> createMinInclusive(Facet value) {
        return new JAXBElement<Facet>(_MinInclusive_QNAME, Facet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumFacet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "minLength")
    public JAXBElement<NumFacet> createMinLength(NumFacet value) {
        return new JAXBElement<NumFacet>(_MinLength_QNAME, NumFacet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://www.twwwireless.com.br/reluzcap/wsreluzcap", name = "dateTime")
    public JAXBElement<XMLGregorianCalendar> createDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataSet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://www.twwwireless.com.br/reluzcap/wsreluzcap", name = "DataSet")
    public JAXBElement<DataSet> createDataSet(DataSet value) {
        return new JAXBElement<DataSet>(_DataSet_QNAME, DataSet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoFixedFacet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "enumeration")
    public JAXBElement<NoFixedFacet> createEnumeration(NoFixedFacet value) {
        return new JAXBElement<NoFixedFacet>(_Enumeration_QNAME, NoFixedFacet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExplicitGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "choice")
    public JAXBElement<ExplicitGroup> createChoice(ExplicitGroup value) {
        return new JAXBElement<ExplicitGroup>(_Choice_QNAME, ExplicitGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://www.twwwireless.com.br/reluzcap/wsreluzcap", name = "string")
    public JAXBElement<String> createString(String value) {
        return new JAXBElement<String>(_String_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumFacet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "maxLength")
    public JAXBElement<NumFacet> createMaxLength(NumFacet value) {
        return new JAXBElement<NumFacet>(_MaxLength_QNAME, NumFacet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Keybase }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "key")
    public JAXBElement<Keybase> createKey(Keybase value) {
        return new JAXBElement<Keybase>(_Key_QNAME, Keybase.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExplicitGroup }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "sequence")
    public JAXBElement<ExplicitGroup> createSequence(ExplicitGroup value) {
        return new JAXBElement<ExplicitGroup>(_Sequence_QNAME, ExplicitGroup.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Facet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "maxInclusive")
    public JAXBElement<Facet> createMaxInclusive(Facet value) {
        return new JAXBElement<Facet>(_MaxInclusive_QNAME, Facet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Facet }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "minExclusive")
    public JAXBElement<Facet> createMinExclusive(Facet value) {
        return new JAXBElement<Facet>(_MinExclusive_QNAME, Facet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Wildcard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "anyAttribute")
    public JAXBElement<Wildcard> createAnyAttribute(Wildcard value) {
        return new JAXBElement<Wildcard>(_AnyAttribute_QNAME, Wildcard.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Keybase }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "unique")
    public JAXBElement<Keybase> createUnique(Keybase value) {
        return new JAXBElement<Keybase>(_Unique_QNAME, Keybase.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "https://www.twwwireless.com.br/reluzcap/wsreluzcap", name = "int")
    public JAXBElement<Integer> createInt(Integer value) {
        return new JAXBElement<Integer>(_Int_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocalElement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "element", scope = GroupType.class)
    public JAXBElement<LocalElement> createGroupTypeElement(LocalElement value) {
        return new JAXBElement<LocalElement>(_GroupTypeElement_QNAME, LocalElement.class, GroupType.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GroupRef }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.w3.org/2001/XMLSchema", name = "group", scope = GroupType.class)
    public JAXBElement<GroupRef> createGroupTypeGroup(GroupRef value) {
        return new JAXBElement<GroupRef>(_GroupTypeGroup_QNAME, GroupRef.class, GroupType.class, value);
    }

}
