package br.com.tokiomarine.arquitetura.smsservice.domain;

public enum MessageStatus {

	ACCEPTED, SENT, ERROR, SCHEDULED, DELIVERED, REJECTED, REPLIED;

}
