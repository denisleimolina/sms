package br.com.tokiomarine.arquitetura.smsservice.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.tokiomarine.arquitetura.smsservice.domain.Blacklist;

public interface BlacklistRepository extends MongoRepository<Blacklist, String> {

	public Optional<Blacklist> findByNumber(String number);

}