package br.com.tokiomarine.arquitetura.smsservice.provider.tww;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.MessageReply;
import br.com.tokiomarine.arquitetura.smsservice.domain.MessageStatus;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceNotFoundException;
import br.com.tokiomarine.arquitetura.smsservice.provider.MessageReplyProcessor;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.client.SoapClient;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.mapper.MessageReplyMapper;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.mapper.TWWStatus;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.BuscaSMSMONaoLido;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.OutDataSetMO;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.SmsMO;
import br.com.tokiomarine.arquitetura.smsservice.service.MessageService;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategy;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ProviderStrategy(name = Provider.TWW)
public class TWWMessageReplyProcessor implements MessageReplyProcessor {

	private SoapClient soapClient;

	private AppProperties properties;

	private MessageReplyMapper messageReplyMapper;

	private MessageService messageService;

	public TWWMessageReplyProcessor(SoapClient soapClient, AppProperties properties, MessageReplyMapper messageReplyMapper,
			MessageService messageService) {
		this.soapClient = soapClient;
		this.properties = properties;
		this.messageReplyMapper = messageReplyMapper;
		this.messageService = messageService;
	}

	@Override
	public void synchronize(MessageReply messageReply) throws Throwable {
		SmsMO smsMO = (SmsMO) messageReply.getReply();
		MessageStatus status = TWWStatus.getStatus(smsMO.getStatus());

		try {
			final Message message = messageService.findBySincronizeKey(messageReply.getSyncKey());
			
			message.setStatus(status);
			message.addReply(toLocalDateTime(smsMO.getDataEnv()), smsMO.getMensagem());
			message.addEvent(messageReply.getReply());
			
			messageService.save(message);
			
			log.info("[{}] Mensagem sincronizada com sucesso [id={}]", message.getProvider(), message.getId());
		} catch (ResourceNotFoundException e) {
			log.error("[{}] Mensagem não encontrada para sincronização [SyncKey={}]", messageReply.getProvider(),
					messageReply.getSyncKey());
		}
	}

	private LocalDateTime toLocalDateTime(String date) {
		return OffsetDateTime.parse(date).toLocalDateTime();
	}

	@Override
	public List<MessageReply> fetch() throws Throwable {
		BuscaSMSMONaoLido buscaSMSMONaoLido = new BuscaSMSMONaoLido();
		buscaSMSMONaoLido.setNumUsu(properties.getTww().getUsername());
		buscaSMSMONaoLido.setSenha(properties.getTww().getPassword());

		OutDataSetMO response = soapClient.searchSMS(buscaSMSMONaoLido);

		return messageReplyMapper.toMessageReply(response);
	}

}
