package br.com.tokiomarine.arquitetura.smsservice.domain;

public enum Provider {

	TWILIO, DIRECT_ONE, TWW;

}
