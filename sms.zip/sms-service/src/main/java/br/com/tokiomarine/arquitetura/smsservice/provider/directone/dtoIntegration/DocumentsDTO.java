package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DocumentsDTO {
	
	    private String cpf;
	    private PhonesDTO phone;

}
