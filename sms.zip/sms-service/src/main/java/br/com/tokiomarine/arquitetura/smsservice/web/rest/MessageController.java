package br.com.tokiomarine.arquitetura.smsservice.web.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.ProviderTrace;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceNotFoundException;
import br.com.tokiomarine.arquitetura.smsservice.service.MessageService;
import br.com.tokiomarine.arquitetura.smsservice.service.dto.MessageFilterDTO;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/v1/messages")
public class MessageController {

	private MessageService service;

	@Autowired
	public MessageController(MessageService service) {
		this.service = service;
	}

	@GetMapping
	@ApiOperation(value = "", nickname = "listMessage")
	public Page<Message> list(Pageable pageable) {
		return service.findAll(pageable);
	}

	@PostMapping
	@SuppressWarnings("squid:S4684")
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "", nickname = "createMessage")
	public Message create(@Validated @RequestBody Message message) throws Throwable {
		return service.create(message);
	}

	@GetMapping("/{id}")
	@ApiOperation(value = "", nickname = "readMessage")
	public Message read(@PathVariable String id) throws Throwable {
		return service.read(id);
	}

	@GetMapping("/{id}/trace")
	@ApiOperation(value = "", nickname = "readTrace")
	public List<ProviderTrace> readTrace(@PathVariable String id) throws Throwable {
		return service.find(id).orElseThrow(ResourceNotFoundException::new).getTrace();
	}

	@GetMapping("/{id}/events")
	@ApiOperation(value = "", nickname = "readEvents")
	public List<Object> readEvents(@PathVariable String id) throws Throwable {
		return service.find(id).orElseThrow(ResourceNotFoundException::new).getEvents();
	}

	@PostMapping("/search")
	@ApiOperation(value = "", nickname = "createSearchMessage")
	public Page<Message> createSearch(Pageable pageable, @RequestBody MessageFilterDTO filters) {
		return service.findAll(pageable, filters);
	}
}
