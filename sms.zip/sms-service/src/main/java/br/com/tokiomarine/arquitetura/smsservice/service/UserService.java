package br.com.tokiomarine.arquitetura.smsservice.service;

import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.domain.Role;
import br.com.tokiomarine.arquitetura.smsservice.domain.User;
import br.com.tokiomarine.arquitetura.smsservice.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserService extends AbstractCrudService<User, String> implements UserDetailsService {

	private PasswordEncoder passwordEncoder;

	private AppProperties properties;

	@Autowired
	public UserService(UserRepository repository, PasswordEncoder passwordEncoder, AppProperties properties) {
		super(repository);
		this.passwordEncoder = passwordEncoder;
		this.properties = properties;
	}

	@PostConstruct
	public void createDefaultAdminUser() {
		Optional<User> optional = ((UserRepository) repository).findByUsername(properties.getAdmin().getUsername());

		if (optional.isPresent()) {
			return;
		}

		final User adminUser = new User(properties.getAdmin().getUsername(), properties.getAdmin().getDefaultPassword(),
				Role.ADMIN);

		log.info("Criando usuário admin padrão: {}", properties.getAdmin().getUsername());

		create(adminUser);
	}

	public void create(User user) {
		user.setEnabled(true);

		encodePassword(user);

		save(user);
	}

	public void encodePassword(User user) {
		final String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return ((UserRepository) repository).findByUsername(username)
				.orElseThrow(() -> new UsernameNotFoundException("User " + username + " not found"));
	}

	public User getCurrent() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null || !authentication.isAuthenticated()) {
			return null;
		}

		return (User) authentication.getPrincipal();
	}

}
