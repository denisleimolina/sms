package br.com.tokiomarine.arquitetura.smsservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import br.com.tokiomarine.arquitetura.smsservice.provider.tww.client.SoapClient;

@Configuration
public class TWWConfiguration {

	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl");
		return marshaller;
	}

	@Bean
	public SoapClient client(Jaxb2Marshaller marshaller, AppProperties properties) {
		SoapClient client = new SoapClient();
		client.setDefaultUri(properties.getTww().getUri());
		client.setMarshaller(marshaller);
		client.setUnmarshaller(marshaller);
		return client;
	}

}
