package br.com.tokiomarine.arquitetura.smsservice.provider.directone.mapper;

import java.util.HashMap;
import java.util.Map;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageStatus;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.EventType;

public class DirectOneStatus {

	public static final String PROCESSED = "Processed";
	public static final String DROPPED 	= "Dropped";
	public static final String DELIVERED  = "Delivered";
	public static final String BOUNCE  = "Bounce";
	public static final String SENT_TO_PROVIDER  = "SentToProvider";
	public static final String REPLY  = "Reply";
	public static final String CLICK  = "Click";

	private DirectOneStatus() {

	}

	private static final Map<EventType, MessageStatus> mapStatus;
	static {
		mapStatus = new HashMap<>();
		mapStatus.put(EventType.PROCESSED, MessageStatus.SENT);
		mapStatus.put(EventType.DROPPED, MessageStatus.ERROR);
		mapStatus.put(EventType.DELIVERED, MessageStatus.DELIVERED);
		mapStatus.put(EventType.BOUNCE, MessageStatus.ERROR);
		mapStatus.put(EventType.SEND_TO_PROVIDER, MessageStatus.SENT);
		mapStatus.put(EventType.REPLY, MessageStatus.REPLIED);
		mapStatus.put(EventType.CLICK, MessageStatus.DELIVERED);
	}

	public static MessageStatus getStatus(EventType type) {
		if (!mapStatus.containsKey(type)) {
			return MessageStatus.ERROR;
		}
		
		return mapStatus.get(type);
	}

}
