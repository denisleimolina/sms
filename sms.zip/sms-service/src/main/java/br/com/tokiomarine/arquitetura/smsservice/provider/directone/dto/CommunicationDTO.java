package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CommunicationDTO {
	@JsonProperty("CommunicationId")
	private String communicationId;

	@JsonProperty("IsTest")
	private Boolean isTest;

	@JsonProperty("Customers")
	private List<CustomersDTO> customers = new ArrayList<>();

	@JsonInclude(Include.NON_NULL)
	@JsonFormat(shape=JsonFormat.Shape.STRING)
	@JsonProperty("ScheduleDate")
	private OffsetDateTime scheduleDate;	
}

