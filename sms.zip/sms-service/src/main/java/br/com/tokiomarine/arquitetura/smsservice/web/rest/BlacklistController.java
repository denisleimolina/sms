package br.com.tokiomarine.arquitetura.smsservice.web.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.tokiomarine.arquitetura.smsservice.domain.Blacklist;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceNotFoundException;
import br.com.tokiomarine.arquitetura.smsservice.service.BlacklistService;
import br.com.tokiomarine.arquitetura.smsservice.service.dto.BlacklistFilterDTO;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/v1/blacklist-items")
public class BlacklistController {

	@Autowired
	private BlacklistService service;

	@Autowired
	public BlacklistController(BlacklistService service) {
		this.service = service;
	}

	@PostMapping
	@SuppressWarnings("squid:S4684")
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "", nickname = "createBlacklist")
	public Blacklist create(@Validated @RequestBody Blacklist blacklist) {
		return service.create(blacklist);
	}

	@GetMapping
	@ApiOperation(value = "", nickname = "findAllBlacklist")
	public Page<Blacklist> findAll(Pageable pageable) {
		return service.findAll(pageable);
	}

	@PostMapping("/search")
	@ApiOperation(value = "", nickname = "createSearchBlacklist")
	public Page<Blacklist> createSearch(Pageable pageable, @RequestBody BlacklistFilterDTO filters) {
		return service.findAll(pageable, filters);
	}

	@PostMapping("/exclusion")
	@SuppressWarnings("squid:S4684")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@ApiOperation(value = "", nickname = "deleteBlacklist")
	public void delete(@RequestBody Blacklist blacklist) {
		Blacklist content = service.findByNumber(blacklist.getNumber()).orElseThrow(ResourceNotFoundException::new);
		service.delete(content);
	}
}