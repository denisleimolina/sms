package br.com.tokiomarine.arquitetura.smsservice.provider;

import br.com.tokiomarine.arquitetura.smsservice.domain.Message;

public interface MessageSender {

	void send(Message message) throws ProviderException;

	void synchronize(Message message) throws ProviderException;
	
	void schedule(Message message) throws ProviderException;

}
