package br.com.tokiomarine.arquitetura.smsservice.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.arquitetura.smsservice.domain.Blacklist;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceAlreadyExistsException;
import br.com.tokiomarine.arquitetura.smsservice.repository.BlacklistRepository;
import br.com.tokiomarine.arquitetura.smsservice.service.dto.BlacklistFilterDTO;
import br.com.tokiomarine.arquitetura.smsservice.service.query.BlacklistQueryFactory;

@Service
public class BlacklistService extends AbstractCrudService<Blacklist, String> {

	private MongoTemplate mongoTemplate;

	private UserService userService;

	private BlacklistQueryFactory queryFactory;

	@Autowired
	public BlacklistService(BlacklistRepository repository, UserService userService, BlacklistQueryFactory queryFactory,
			MongoTemplate mongoTemplate) {
		super(repository);
		this.userService = userService;
		this.queryFactory = queryFactory;
		this.mongoTemplate = mongoTemplate;
	}

	public Blacklist create(Blacklist blacklist) {
		Optional<Blacklist> content = findByNumber(blacklist.getNumber());
		if(content.isPresent()) {
			throw new ResourceAlreadyExistsException();
		}
		
		blacklist.setCreatedBy(userService.getCurrent());
		blacklist.setCreatedAt(LocalDateTime.now());
		return save(blacklist);
	}

	public Page<Blacklist> findAll(Pageable pageable, BlacklistFilterDTO filters) {
		Query query = queryFactory.getQuery(filters);
		query.with(pageable);

		List<Blacklist> content = mongoTemplate.find(query, Blacklist.class);
		return PageableExecutionUtils.getPage(content, pageable, () -> mongoTemplate.count(query, Blacklist.class));
	}
	
	public Optional<Blacklist> findByNumber(String number) {
		BlacklistRepository blacklistRepository = (BlacklistRepository) repository;
		return blacklistRepository.findByNumber(number);
	}
}
