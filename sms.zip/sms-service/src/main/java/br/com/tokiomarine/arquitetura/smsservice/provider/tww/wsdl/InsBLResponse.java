
package br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InsBLResult" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "insBLResult"
})
@XmlRootElement(name = "InsBLResponse")
public class InsBLResponse {

    @XmlElement(name = "InsBLResult")
    protected int insBLResult;

    /**
     * Gets the value of the insBLResult property.
     * 
     */
    public int getInsBLResult() {
        return insBLResult;
    }

    /**
     * Sets the value of the insBLResult property.
     * 
     */
    public void setInsBLResult(int value) {
        this.insBLResult = value;
    }

}
