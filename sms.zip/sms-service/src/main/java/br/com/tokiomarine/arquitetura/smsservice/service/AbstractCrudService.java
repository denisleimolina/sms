package br.com.tokiomarine.arquitetura.smsservice.service;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Service
@Validated
public abstract class AbstractCrudService<T, ID extends Serializable> {

	protected Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	protected MongoRepository<T, ID> repository;

	public AbstractCrudService(MongoRepository<T, ID> repository) {
		this.repository = repository;
	}

	public Page<T> findAll(Pageable pageable) {
		return repository.findAll(pageable);
	}

	public List<T> findAll() {
		return repository.findAll();
	}

	public Optional<T> find(ID id) {
		return repository.findById(id);
	}

	public T save(@Valid T entity) {
		return repository.save(entity);
	}
	
	public void save(@Valid Iterable<T> entity) {
		repository.saveAll(entity);
	}
	
	public void delete(T entity) {
		repository.delete(entity);
	}

}
