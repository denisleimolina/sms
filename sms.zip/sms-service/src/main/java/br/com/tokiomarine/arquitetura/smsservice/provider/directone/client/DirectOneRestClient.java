package br.com.tokiomarine.arquitetura.smsservice.provider.directone.client;
import java.time.Duration;

import br.com.tokiomarine.arquitetura.smsservice.domain.ResponseToken;
import br.com.tokiomarine.arquitetura.smsservice.domain.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import javax.annotation.PostConstruct;
import org.springframework.web.client.RestTemplate;
import lombok.SneakyThrows;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.CommunicationDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.CommunicationNewDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.TokenIntegration;


@Component
public class DirectOneRestClient {


	private static final String AUTHENTICATION_URL = "https://apicore.d1.cx/login/5dd3f3742320431138fa61df/token";
	private static final String TENANT_ID = "TenantId";

	private AppProperties properties;

	private ObjectMapper mapperConverter;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	public DirectOneRestClient(AppProperties properties) {
		this.properties = properties;
	}

	@PostConstruct
	public void postConstruct() {
		getAutenticateJwt(); // @formatter:on
	}

	public ResponseEntity<String> sendSMS(CommunicationDTO communication) {
		HttpHeaders headers = verifyToken();

		return restTemplate.postForEntity("/transactional/send",
				new HttpEntity<>(communication, headers), String.class);
	}

	public ResponseEntity<TokenIntegration> sendNewSMS(CommunicationNewDTO communication) {
		HttpHeaders headers = verifyToken();
		return restTemplate.postForEntity("/journey/v1/send",
				new HttpEntity<>(communication, headers), TokenIntegration.class);
	}


	private void getAutenticateJwt() {
		this.restTemplate = new RestTemplateBuilder() // @formatter:off
				.setConnectTimeout(Duration.ofMillis(properties.getDirectOne().getConnectTimeout()))
				.setReadTimeout(Duration.ofMillis(properties.getDirectOne().getReadTimeout()))
				.rootUri(properties.getDirectOne().getUrl())
				.build(); // @formatter:on
	}

	private HttpHeaders verifyToken() {
		ResponseEntity<TokenIntegration> jwtVerify = createToken();
		
		TokenIntegration tms = new TokenIntegration();
		
		if(tms.expires_in >= 60 ) {
			ResponseEntity<TokenIntegration> renewToken = createToken();
		}else {
			ResponseEntity<TokenIntegration> renewToken = sendNewSMS(CommunicationNewDTO);
		}
		
		
		
		tms = mapperConverter.convertValue(jwtVerify, TokenIntegration.class);

		return new HttpHeaders();
	}

	@SneakyThrows
	private ResponseEntity<TokenIntegration> createToken() {
		User authenticationUser = getAuthenticationUser();
		String authenticationBody = getBody(authenticationUser);
		HttpHeaders authenticationHeaders = getheaders();
		HttpEntity<String> authenticationEntity = new HttpEntity<String>(authenticationBody,
				authenticationHeaders);
		try {
			ResponseEntity<ResponseToken> authenticationResponse = restTemplate.exchange(AUTHENTICATION_URL,
					HttpMethod.POST, authenticationEntity, ResponseToken.class);
			System.out.println(authenticationResponse.getStatusCode().equals(HttpStatus.OK));
			if (authenticationResponse.getStatusCode().equals(HttpStatus.OK)) {
				String token = "Bearer" + authenticationResponse.getBody().getToken();
				HttpHeaders headers = getheaders();
				headers.set("Authorization", token);
				HttpEntity<String> jwtEntity = new HttpEntity<String>(headers);

			}

		} catch (Exception ex) {
			System.out.println(ex);
		}

		return null;
	}



	private User getAuthenticationUser(){
		User user = new User();
		return user;
	}

	private String getBody(final User user) throws JsonProcessingException{
		return  new ObjectMapper().writeValueAsString(user);
	}


	private HttpHeaders getheaders() {
	HttpHeaders headers = new HttpHeaders();
		headers.set(TENANT_ID, properties.getDirectOne().getTenantId());
		return headers;
	}
	

	
	

	
	
	
}