package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.CustomersNewDTO;
import lombok.Data;

@Data
public class CustomersNewDTO {
	@JsonProperty("Customer")
	private CustomerNewDTO customer;
	
	@JsonProperty("ExternalKey")
	private String externalKey;
	
	@JsonProperty("Variables")
	private ObjectNode variable;
	
	public void addVariable(String fieldName, String value) {
		if(variable == null) {
			variable = new ObjectMapper().createObjectNode();
		}
		variable.put(fieldName, value);
	}
}
