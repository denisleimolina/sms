package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Data;
import lombok.Builder;

@Data
@Builder
@Document(collection = WebhookResponse.COLLECTION_NAME)
public class WebhookResponse {

	public static final String COLLECTION_NAME = "sms_webhook_response";

	@Id
	@JsonProperty(access = Access.READ_ONLY)
	private String id;
	
	private Provider provider;

	private Object response;
	
	@Builder.Default
	private Boolean processed = false;

	@JsonProperty(access = Access.READ_ONLY)
	private LocalDateTime receivedAt;

}