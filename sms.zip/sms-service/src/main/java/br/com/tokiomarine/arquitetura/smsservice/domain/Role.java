package br.com.tokiomarine.arquitetura.smsservice.domain;

import org.springframework.security.core.GrantedAuthority;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class Role implements GrantedAuthority {

	private static final long serialVersionUID = 1L;

	public static final String ADMIN = "ROLE_ADMIN";

	private String name;

	public Role() {
		super();
	}

	public Role(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	@JsonIgnore
	public String getAuthority() {
		return getName();
	}
}
