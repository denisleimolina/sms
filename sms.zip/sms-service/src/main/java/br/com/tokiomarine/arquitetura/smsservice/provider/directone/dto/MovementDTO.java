package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import lombok.Data;

@Data
public class MovementDTO {

	private String id;
	private String date;
	private String fileName;
	private String lot;

}
