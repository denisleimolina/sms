package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class CustomersDTO {
	@JsonProperty("Customer")
	private CustomerDTO customer;
	
	@JsonProperty("ExternalKey")
	private String externalKey;
	
	@JsonProperty("Variables")
	private ObjectNode variable;
	
	public void addVariable(String fieldName, String value) {
		if(variable == null) {
			variable = new ObjectMapper().createObjectNode();
		}
		variable.put(fieldName, value);
	}
	
}
