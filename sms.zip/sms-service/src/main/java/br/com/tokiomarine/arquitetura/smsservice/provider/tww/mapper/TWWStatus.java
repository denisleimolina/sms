package br.com.tokiomarine.arquitetura.smsservice.provider.tww.mapper;

import java.util.HashMap;
import java.util.Map;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageStatus;

public class TWWStatus {

	public static final String RECEIVED_MESSAGE = "OK";
	public static final String SENT_MESSAGE	= "OP";
	public static final String CONFIRMED_RECEIPT = "CL";
	public static final String ERROR_PROCESSING = "ER";
	public static final String NO_CARRIER = "E0";
	public static final String REJECTED_BLACKLIST = "E1";
	public static final String REJECTED_CARRIER = "E4";
	public static final String EXPIRED_CARRIER = "E6";
	public static final String REJECTED_CREDIT = "E7";
	public static final String REPLY = "MO";

	private TWWStatus() {

	}

	private static final Map<String, MessageStatus> mapStatus;
	static {
		mapStatus = new HashMap<>();
		mapStatus.put(RECEIVED_MESSAGE, MessageStatus.SENT);
		mapStatus.put(SENT_MESSAGE, MessageStatus.SENT);
		mapStatus.put(CONFIRMED_RECEIPT, MessageStatus.DELIVERED);
		mapStatus.put(ERROR_PROCESSING, MessageStatus.ERROR);
		mapStatus.put(NO_CARRIER, MessageStatus.ERROR);
		mapStatus.put(REJECTED_BLACKLIST, MessageStatus.ERROR);
		mapStatus.put(REJECTED_CARRIER, MessageStatus.ERROR);
		mapStatus.put(EXPIRED_CARRIER, MessageStatus.ERROR);
		mapStatus.put(REJECTED_CREDIT, MessageStatus.ERROR);
		mapStatus.put(REPLY, MessageStatus.REPLIED);
	}

	public static MessageStatus getStatus(String status) {
		if (!mapStatus.containsKey(status)) {
			return MessageStatus.ERROR;
		}
		return mapStatus.get(status);
	}

}
