package br.com.tokiomarine.arquitetura.smsservice.exception;

public class BlacklistException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private Object resource;

	public BlacklistException(Object resource) {
		super();
		this.resource = resource;
	}

	public BlacklistException(Object resource, Throwable cause) {
		super(cause);
		this.resource = resource;
	}

	public Object getResource() {
		return resource;
	}
}
