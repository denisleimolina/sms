package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter @Setter
public class TokenIntegration {

	 public String token_type;
	 public String access_token;
	 public int expires_in;
	 public Long expires_on;

}
