package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration;

import lombok.Data;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@Data
public class CommunicationNewDTO {
	
	@JsonProperty("journeyId")
	public String journeyId;
	
	@JsonProperty("customer")
	public CustomerNewDTO customer;
	
	@JsonProperty("phonesDTO")
	public PhonesDTO phonesDTO;
	
	@JsonProperty("variablesDTO")
	public VariablesDTO variablesDTO;
	
	@JsonProperty("correlationId")
	public String correlationId;
	
	@JsonProperty("versionId")
	public String versionId;
	
	@JsonProperty("Customers")
	private List<CustomersNewDTO> customers = new ArrayList<>();
	
	@JsonInclude(Include.NON_NULL)
	@JsonFormat(shape=JsonFormat.Shape.STRING)
	@JsonProperty("ScheduleDate")
	private OffsetDateTime scheduleDate;
	
}
