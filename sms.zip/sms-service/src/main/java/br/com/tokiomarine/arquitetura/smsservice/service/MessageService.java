package br.com.tokiomarine.arquitetura.smsservice.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.domain.Blacklist;
import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.MessageStatus;
import br.com.tokiomarine.arquitetura.smsservice.exception.BlacklistException;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceNotFoundException;
import br.com.tokiomarine.arquitetura.smsservice.provider.MessageSender;
import br.com.tokiomarine.arquitetura.smsservice.repository.MessageRepository;
import br.com.tokiomarine.arquitetura.smsservice.service.dto.MessageFilterDTO;
import br.com.tokiomarine.arquitetura.smsservice.service.query.MessageQueryFactory;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategyFactory;

@Service
public class MessageService extends AbstractCrudService<Message, String> {

	private MongoTemplate mongoTemplate;

	private MessageQueryFactory queryFactory;

	private ProviderStrategyFactory strategyFactory;

	private UserService userService;

	private BlacklistService blacklistService;

	private AppProperties properties;

	@Autowired
	public MessageService(MessageRepository repository, MongoTemplate mongoTemplate, MessageQueryFactory queryFactory,
			ProviderStrategyFactory strategyFactory, UserService userService, BlacklistService blacklistService,
			AppProperties properties) {
		super(repository);
		this.mongoTemplate = mongoTemplate;
		this.queryFactory = queryFactory;
		this.strategyFactory = strategyFactory;
		this.userService = userService;
		this.blacklistService = blacklistService;
		this.properties = properties;
	}

	public Page<Message> findAll(Pageable pageable, MessageFilterDTO filters) {
		Query query = queryFactory.getQuery(filters);
		query.with(pageable);

		List<Message> content = mongoTemplate.find(query, Message.class);
		return PageableExecutionUtils.getPage(content, pageable, () -> mongoTemplate.count(query, Message.class));
	}

	public Message create(Message message) throws Throwable {
		message.setId(UUID.randomUUID().toString());
		message.setCreatedAt(LocalDateTime.now());
		message.setStatus(MessageStatus.ACCEPTED);
		message.setCreatedBy(userService.getCurrent());

		if (message.getProvider() == null) {
			message.setProvider(properties.getDefaultProvider());
		}

		try {
			checkBlacklist(message);

			final MessageSender messageSender = strategyFactory.getStrategy(MessageSender.class, message.getProvider());

			Long startTime = System.currentTimeMillis();

			if (message.getScheduledAt() == null) {
				messageSender.send(message);
				message.setStatus(MessageStatus.SENT);
			} else {
				messageSender.schedule(message);
				message.setStatus(MessageStatus.SCHEDULED);
			}

			Long responseTime = System.currentTimeMillis() - startTime;
			message.addTrace("responseTime", responseTime.toString());

			logger.info("[{}] Mensagem enviada com sucesso [id={}] responseTime=[{} ms]", message.getProvider(),
					message.getId(), responseTime);

			return message;
		} catch (BlacklistException e) {
			logger.error("[{}] Telefone esta na blacklist [id={}]", message.getProvider(), message.getId(), e);
			message.setStatus(MessageStatus.REJECTED);
			throw e;
		} catch (Exception e) {
			logger.error("[{}] Erro ao enviar mensagem [id={}]", message.getProvider(), message.getId(), e);
			message.setStatus(MessageStatus.ERROR);
			throw e;
		} finally {
			save(message);
		}
	}

	public Message read(String id) throws Throwable {
		final Message message = find(id).orElseThrow(ResourceNotFoundException::new);

		if (message.isReplied()) {
			return message;
		}

		try {
			final MessageSender messageSender = strategyFactory.getStrategy(MessageSender.class, message.getProvider());
			messageSender.synchronize(message);
			logger.info("[{}] Mensagem sincronizada com sucesso [id={}]", message.getProvider(), message.getId());

			return message;
		} catch (Exception e) {
			logger.error("[{}] Erro ao sincronizar a mensagem [id={}]", message.getProvider(), message.getId(), e);
			throw e;
		} finally {
			save(message);
		}
	}

	public Message findBySincronizeKey(String key) {
		return Optional.ofNullable(((MessageRepository) repository).findBySincronizeKey(key))
				.orElseThrow(ResourceNotFoundException::new);
	}

	private void checkBlacklist(Message message) {
		Optional<Blacklist> blacklist = blacklistService.findByNumber(message.getTo());
		if (blacklist.isPresent()) {
			throw new BlacklistException(message);
		}
	}
}
