package br.com.tokiomarine.arquitetura.smsservice.jackson;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class PhoneNumberDeserializer extends JsonDeserializer<String> {
	private static final String DDI = "55";
	
	@Override
	public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
		if (p.getText().length() == 11) {
			return new StringBuilder().append(DDI).append(p.getText()).toString();
		}

		return p.getText();
	}
}
