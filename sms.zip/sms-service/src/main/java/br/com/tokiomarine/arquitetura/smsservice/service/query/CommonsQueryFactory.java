package br.com.tokiomarine.arquitetura.smsservice.service.query;

import java.time.LocalDateTime;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

@Component
public class CommonsQueryFactory {

	private final String CREATED_AT = "createdAt";

	public void addCriteriaSortAndOrder(Query query, Direction sortOrder, String sortBy) {
		if (sortBy == null || sortBy.isEmpty()) {
			return;
		}

		if (sortOrder == null) {
			sortOrder = Direction.ASC;
		}

		query.with(Sort.by(sortOrder, sortBy));
	}

	public void addCriteriaCreatedAt(Query query, LocalDateTime createdAfterAt, LocalDateTime createdBeforeAt,
			LocalDateTime createdAt) {
		if (createdBeforeAt != null && createdAfterAt != null) {
			Criteria criteria = new Criteria();
			criteria.andOperator( // @formatter:off
					Criteria.where(CREATED_AT).lte(createdBeforeAt), Criteria.where(CREATED_AT).gte(createdAfterAt)); // @formatter:on

			query.addCriteria(criteria);
			return;
		}

		if (createdBeforeAt != null) {
			query.addCriteria(Criteria.where(CREATED_AT).lte(createdBeforeAt));
			return;
		}

		if (createdAfterAt != null) {
			query.addCriteria(Criteria.where(CREATED_AT).gte(createdAfterAt));
			return;
		}

		if (createdAt != null) {
			query.addCriteria(Criteria.where(CREATED_AT).is(createdAt));
		}
	}

	public void addCriteria(Query query, String key, Boolean value) {
		if (value != null) {
			query.addCriteria(Criteria.where(key).is(value));
		}
	}

	public void addCriteria(Query query, String key, String value) {
		if (value != null && !value.isEmpty()) {
			query.addCriteria(Criteria.where(key).is(value));
		}
	}

	public void addEnumCriteria(Query query, String key, Enum<?> value) {
		if (value != null) {
			query.addCriteria(Criteria.where(key).is(value));
		}
	}

	public void addCriteria(Query query, String key, Object value) {
		if (value != null) {
			query.addCriteria(Criteria.where(key).is(value));
		}
	}
	
}
