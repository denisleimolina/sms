package br.com.tokiomarine.arquitetura.smsservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "app")
public class AppProperties {
	private Provider defaultProvider = Provider.TWW;
	private Twilio twilio;
	private Tww tww;
	private DirectOne directOne;
	private Admin admin;
	
	@Data
	public static class Twilio {
		private String username;
		private String password;
		private String defaultFrom;
	}
	
	@Data
	public static class Tww {
		private String username;
		private String password;
		private String uri;
	}
	
	@Data
	public static class DirectOne {
		private int connectTimeout = 120000;
		private int readTimeout = 120000;
		private String url;
		private String username;
		private String password;
		private String tenantId;
		private String communicationId;
		private boolean test = false;
	}
	
	@Data
	public static class Admin {
		private String username;
		private String defaultPassword;
	}
}
