package br.com.tokiomarine.arquitetura.smsservice.service.query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.arquitetura.smsservice.service.dto.MessageFilterDTO;

@Component
public class MessageQueryFactory {

	private static final String STATUS = "status";
	private static final String PROVIDER = "provider";
	private static final String FROM = "from";
	private static final String TO = "to";
	private static final String METADATA = "metadata";

	@Autowired
	private CommonsQueryFactory commonsQueryFactory;

	public Query getQuery(MessageFilterDTO filters) {
		Query query = new Query();

		if (filters.getStatus() != null) {
			commonsQueryFactory.addEnumCriteria(query, STATUS, filters.getStatus());
		}

		if (filters.getProvider() != null) {
			commonsQueryFactory.addEnumCriteria(query, PROVIDER, filters.getProvider());
		}

		commonsQueryFactory.addCriteriaCreatedAt(query, filters.getCreatedAfterAt(), filters.getCreatedBeforeAt(),
				filters.getCreatedAt());
		commonsQueryFactory.addCriteria(query, FROM, filters.getFrom());
		commonsQueryFactory.addCriteria(query, TO, filters.getTo());

		filters.getMetadata()
				.forEach((key, value) -> commonsQueryFactory.addCriteria(query, METADATA + "." + key, value));

		return query;
	}

}
