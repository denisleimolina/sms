package br.com.tokiomarine.arquitetura.smsservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.tokiomarine.arquitetura.smsservice.domain.WebhookResponse;

public interface WebhookRepository extends MongoRepository<WebhookResponse, String> {

}