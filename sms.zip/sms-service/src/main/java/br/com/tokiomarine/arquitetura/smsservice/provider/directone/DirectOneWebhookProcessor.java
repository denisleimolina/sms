package br.com.tokiomarine.arquitetura.smsservice.provider.directone;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;

import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.MessageStatus;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.domain.WebhookResponse;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceNotFoundException;
import br.com.tokiomarine.arquitetura.smsservice.provider.WebhookProcessor;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.EventDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto.EventType;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.mapper.DirectOneStatus;
import br.com.tokiomarine.arquitetura.smsservice.service.MessageService;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategy;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ProviderStrategy(name = Provider.DIRECT_ONE)
public class DirectOneWebhookProcessor implements WebhookProcessor {

	private MessageService messageService;

	@Autowired
	public DirectOneWebhookProcessor(MessageService messageService) {
		this.messageService = messageService;
	}

	@Override
	public void synchronize(WebhookResponse webhookResponse) throws Throwable {
		List<EventDTO> events = parse(webhookResponse.getResponse());

		for (EventDTO event : events) {
			log.info("[{}] Sincronizando a mensagem pelo evento de webhook {}", webhookResponse.getProvider(), event);

			String externalKey = event.getExternalKey();
			EventType eventType = event.getEventType();

			try {
				final Message message = messageService.find(externalKey).orElseThrow(ResourceNotFoundException::new);

				if (isPositionAfter(message, eventType)) {
					MessageStatus messageStatus = DirectOneStatus.getStatus(eventType);
					message.setStatus(messageStatus);
				}

				if (eventType == EventType.REPLY) {
					message.addReply(convertToLocalDateTime(event.getDate()), event.getResponse());
				}

				message.addEvent(event);
				messageService.save(message);

				log.info("[{}] Mensagem sincronizada com sucesso [id={}]", message.getProvider(), message.getId());
			} catch (ResourceNotFoundException e) {
				log.error("[{}] Mensagem não encontrada para sincronização [externalKey={}]",
						webhookResponse.getProvider(), externalKey);
			}
		}
	}

	private boolean isPositionAfter(Message message, EventType eventType) {
		int position = message.getEvents().parallelStream()
				.mapToInt(e -> ((EventDTO) e).getEventType().getPosition()).max().orElse(0);

		return eventType.getPosition() > position;
	}

	private List<EventDTO> parse(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		JavaTimeModule module = new JavaTimeModule();
		module.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
		mapper.registerModule(module);

		String objectString = mapper.writeValueAsString(object);

		return mapper.readValue(objectString, new TypeReference<List<EventDTO>>() {
		});
	}
	
	private LocalDateTime convertToLocalDateTime(String date) {
		return OffsetDateTime.parse(date, DateTimeFormatter.ISO_OFFSET_DATE_TIME).toLocalDateTime();
	}

}
