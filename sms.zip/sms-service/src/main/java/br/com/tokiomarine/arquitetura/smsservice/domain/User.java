package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Document(collection = User.COLLECTION_NAME)
@Data
public class User implements UserDetails {

	private static final long serialVersionUID = 1L;

	public static final String COLLECTION_NAME = "sms_user";

	@Id
	@JsonIgnore
	private String id;

	@Indexed(unique = true)
	private String username;

	@JsonIgnore
	private String password;

	@JsonIgnore
	private List<Role> roles = new ArrayList<>();

	@JsonIgnore
	private Boolean enabled;

	public User() {
		super();
	}

	public User(String username, String password, String role) {
		super();
		this.username = username;
		this.password = password;
		this.addRole(new Role(role));
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public void addRole(Role role) {
		roles.add(role);
	}

	@Override
	@JsonIgnore
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return getRoles();
	}

	@JsonIgnore
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isEnabled() {
		if (enabled == null) {
			enabled = true;
		}

		return enabled;
	}

	public boolean hasRole(String roleName) {
		return roles.stream().anyMatch(role -> role.getName().equals(roleName));
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	@JsonIgnore
	public boolean isUser() {
		return hasRole("ROLE_USER");
	}

	@JsonIgnore
	public boolean isAdmin() {
		return hasRole("ROLE_ADMIN");
	}

}