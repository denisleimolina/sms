package br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "StatusSMS")
@XmlAccessorType(XmlAccessType.FIELD)
public class SmsMO {

	@XmlElement(name = "seunum")
	private String seuNum;
	private String celular;
	private String mensagem;
	private String status;

	@XmlElement(name = "datarec")
	private String dataRec;

	@XmlElement(name = "dataenv")
	private String dataEnv;

	@XmlElement(name = "datastatus")
	private String dataStatus;
	private Long op;

	public String getSeuNum() {
		return seuNum;
	}

	public void setSeuNum(String seuNum) {
		this.seuNum = seuNum;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDataRec() {
		return dataRec;
	}

	public void setDataRec(String dataRec) {
		this.dataRec = dataRec;
	}

	public String getDataEnv() {
		return dataEnv;
	}

	public void setDataEnv(String dataEnv) {
		this.dataEnv = dataEnv;
	}

	public String getDataStatus() {
		return dataStatus;
	}

	public void setDataStatus(String dataStatus) {
		this.dataStatus = dataStatus;
	}

	public Long getOp() {
		return op;
	}

	public void setOp(Long op) {
		this.op = op;
	}

	@Override
	public String toString() {
		return "StatusSms [seuNum=" + seuNum + ", celular=" + celular + ", mensagem=" + mensagem + ", status=" + status
				+ ", dataRec=" + dataRec + ", dataEnv=" + dataEnv + ", dataStatus=" + dataStatus + ", op=" + op + "]";
	}

}
