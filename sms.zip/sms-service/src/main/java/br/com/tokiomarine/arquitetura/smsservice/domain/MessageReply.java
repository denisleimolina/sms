package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = MessageReply.COLLECTION_NAME)
public class MessageReply {
	
	public static final String COLLECTION_NAME = "sms_message_reply";

	@Id
	private String id;
	
	private Provider provider;

	private Object reply;
	
	private String syncKey;
	
	@Builder.Default
	private Boolean processed = false;

	private LocalDateTime createdAt;
	
}
