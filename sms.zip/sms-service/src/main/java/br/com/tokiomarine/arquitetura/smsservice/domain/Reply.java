package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Reply {
	private LocalDateTime date;
	private String body;

	public Reply(LocalDateTime date, String body) {
		this.date = date;
		this.body = body;
	}
	
	
}
