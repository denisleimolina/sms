package br.com.tokiomarine.arquitetura.smsservice.provider.tww.mapper;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.domain.MessageReply;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.OutDataSetMO;
import br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema.SmsMO;

@Component
public class MessageReplyMapper {

	public List<MessageReply> toMessageReply(OutDataSetMO data) {
		List<MessageReply> replies = new ArrayList<>();

		data.getSmsMO().forEach(sms -> replies.add(smsMOToMessageReply(sms)));
		
		return replies; 
	}

	private MessageReply smsMOToMessageReply(SmsMO sms) {
		return MessageReply.builder()
				.provider(Provider.TWW)
				.reply(sms)
				.createdAt(LocalDateTime.now())
				.syncKey(sms.getSeuNum())
				.build();
	}
}
