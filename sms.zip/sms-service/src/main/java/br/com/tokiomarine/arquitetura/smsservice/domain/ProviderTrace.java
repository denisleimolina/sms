package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProviderTrace {

	private LocalDateTime date;

	private String key;

	private Object value;

	public ProviderTrace(String key, Object value) {
		this.date = LocalDateTime.now();
		this.key = key;
		this.value = value;
	}

}
