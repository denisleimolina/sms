package br.com.tokiomarine.arquitetura.smsservice.domain;

import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import br.com.tokiomarine.arquitetura.smsservice.jackson.PhoneNumberDeserializer;
import lombok.Data;

@Data
@Document(collection = Message.COLLECTION_NAME)
public class Message {

	public static final String COLLECTION_NAME = "sms_message";

	@Id
	@JsonProperty(access = Access.READ_ONLY)
	private String id;

	private String from;

	@NotEmpty
	@Size(min = 11)
	@JsonDeserialize(using = PhoneNumberDeserializer.class)
	private String to;

	@NotEmpty
	private String body;

	private LocalDateTime scheduledAt;

	@JsonProperty(access = Access.READ_ONLY)
	private MessageStatus status;

	@JsonProperty(access = Access.READ_ONLY)
	private List<Reply> replies = new LinkedList<>();

	@JsonProperty(access = Access.READ_ONLY)
	@DBRef
	private User createdBy;

	@JsonProperty(access = Access.READ_ONLY)
	private LocalDateTime createdAt;

	private Provider provider;
	
	@JsonIgnore
	private String sincronizeKey;

	@JsonIgnore
	private List<ProviderTrace> trace = new LinkedList<>();
	
	@JsonIgnore
	private List<Object> events = new LinkedList<>();
	
	private Object metadata;

	public void addReply(LocalDateTime date, String body) {
		replies.add(new Reply(date,body));
	}

	public void addTrace(String key, Object value) {
		trace.add(new ProviderTrace(key, value));
	}
	
	public void addEvent(Object event) {
		events.add(event);
	}
	
	@JsonIgnore
	@Transient
	public boolean isReplied() {
		return this.status == MessageStatus.REPLIED;
	}

}