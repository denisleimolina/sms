package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class EventDTO {

	private String communicationId;
	private String communicationName;
	private String shootingId;
	private String externalKey;
	private String eventType;
	private String recipient;
	private String channelKey;
	private String channelKind;
	private String channelName;
	private String date;
	private Boolean isTest;
	private MovementDTO movement;
	private String customerId;
	private String customerName;
	private String customerDocument;
	private String customerIdentification;
	private Map<String, String> properties = new HashMap<>();
	private String url;
	private String userAgent;
	private String ip;
	private String bounceType;
	private String reason;
	private String response;

	public EventType getEventType() {
		return EventType.fromType(this.eventType);
	}

}
