package br.com.tokiomarine.arquitetura.smsservice.provider;

import br.com.tokiomarine.arquitetura.smsservice.domain.WebhookResponse;

public interface WebhookProcessor {

	void synchronize(WebhookResponse webhookResponse) throws Throwable;

}
