package br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl.schema;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import lombok.ToString;

@XmlRootElement(name = "OutDataSet")
@XmlSeeAlso(value = StatusSms.class)
@XmlAccessorType(XmlAccessType.FIELD)
@ToString
public class OutDataSet {

	@XmlElement(name = "StatusSMS")
	private List<StatusSms> statusSms = new ArrayList<>();

	public boolean addStatusSms(StatusSms statusSms) {
		return this.statusSms.add(statusSms);
	}

	public List<StatusSms> getStatusSms() {
		return statusSms;
	}

	public void setStatusSms(List<StatusSms> statusSms) {
		this.statusSms = statusSms;
	}

	public Optional<StatusSms> getFirstStatusSms() {
		return statusSms.stream().findFirst();
	}

	public Optional<String> getFirstStatus() {
		return statusSms.stream().findFirst().map(StatusSms::getStatus);
	}

}
