package br.com.tokiomarine.arquitetura.smsservice.service.dto;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageStatus;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import lombok.Data;

@Data
public class MessageFilterDTO {
	private MessageStatus status;

	private Provider provider;

	private String from;

	private String to;

	private Map<String, Object> metadata = new HashMap<>();

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdAt;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdBeforeAt;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdAfterAt;	

}
