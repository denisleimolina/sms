package br.com.tokiomarine.arquitetura.smsservice.scheduling;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.arquitetura.smsservice.domain.WebhookResponse;
import br.com.tokiomarine.arquitetura.smsservice.service.WebhookService;

@Component
public class WebhookScheduledTasks {
	
	private static final String TIME_ZONE = "America/Sao_Paulo";

	private WebhookService webhookService;

	@Autowired
	public WebhookScheduledTasks(WebhookService webhookService) {
		this.webhookService = webhookService;
	}

	@Scheduled(fixedRate = 1000, initialDelay = 5000)
	public void synchronizeMessageStatus() {
		WebhookResponse webhookResponse = webhookService.findAndModifyByProcessed();
		if (webhookResponse == null) {
			return;
		}

		webhookService.synchronizeMessageStatus(webhookResponse);
	}
	
	@Scheduled(cron = "0 0 1 ? * *", zone = TIME_ZONE)
	public void purgingProcessedWebhooks() {
		webhookService.findAllAndRemoveByProcessed();
	}

}
