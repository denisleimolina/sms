
package br.com.tokiomarine.arquitetura.smsservice.provider.tww.wsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NumUsu" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Senha" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Template" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeuNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Celular" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VarNome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Var1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Var2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Var3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Var4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Agendamento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "numUsu",
    "senha",
    "template",
    "seuNum",
    "celular",
    "varNome",
    "var1",
    "var2",
    "var3",
    "var4",
    "agendamento"
})
@XmlRootElement(name = "EnviaSMSTemplate")
public class EnviaSMSTemplate {

    @XmlElement(name = "NumUsu")
    protected String numUsu;
    @XmlElement(name = "Senha")
    protected String senha;
    @XmlElement(name = "Template")
    protected String template;
    @XmlElement(name = "SeuNum")
    protected String seuNum;
    @XmlElement(name = "Celular")
    protected String celular;
    @XmlElement(name = "VarNome")
    protected String varNome;
    @XmlElement(name = "Var1")
    protected String var1;
    @XmlElement(name = "Var2")
    protected String var2;
    @XmlElement(name = "Var3")
    protected String var3;
    @XmlElement(name = "Var4")
    protected String var4;
    @XmlElement(name = "Agendamento")
    protected String agendamento;

    /**
     * Gets the value of the numUsu property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumUsu() {
        return numUsu;
    }

    /**
     * Sets the value of the numUsu property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumUsu(String value) {
        this.numUsu = value;
    }

    /**
     * Gets the value of the senha property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenha() {
        return senha;
    }

    /**
     * Sets the value of the senha property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenha(String value) {
        this.senha = value;
    }

    /**
     * Gets the value of the template property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplate() {
        return template;
    }

    /**
     * Sets the value of the template property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplate(String value) {
        this.template = value;
    }

    /**
     * Gets the value of the seuNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeuNum() {
        return seuNum;
    }

    /**
     * Sets the value of the seuNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeuNum(String value) {
        this.seuNum = value;
    }

    /**
     * Gets the value of the celular property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCelular() {
        return celular;
    }

    /**
     * Sets the value of the celular property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCelular(String value) {
        this.celular = value;
    }

    /**
     * Gets the value of the varNome property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVarNome() {
        return varNome;
    }

    /**
     * Sets the value of the varNome property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVarNome(String value) {
        this.varNome = value;
    }

    /**
     * Gets the value of the var1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVar1() {
        return var1;
    }

    /**
     * Sets the value of the var1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVar1(String value) {
        this.var1 = value;
    }

    /**
     * Gets the value of the var2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVar2() {
        return var2;
    }

    /**
     * Sets the value of the var2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVar2(String value) {
        this.var2 = value;
    }

    /**
     * Gets the value of the var3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVar3() {
        return var3;
    }

    /**
     * Sets the value of the var3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVar3(String value) {
        this.var3 = value;
    }

    /**
     * Gets the value of the var4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVar4() {
        return var4;
    }

    /**
     * Sets the value of the var4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVar4(String value) {
        this.var4 = value;
    }

    /**
     * Gets the value of the agendamento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgendamento() {
        return agendamento;
    }

    /**
     * Sets the value of the agendamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgendamento(String value) {
        this.agendamento = value;
    }

}
