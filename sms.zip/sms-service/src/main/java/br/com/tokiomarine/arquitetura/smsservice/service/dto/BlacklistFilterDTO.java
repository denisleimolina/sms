package br.com.tokiomarine.arquitetura.smsservice.service.dto;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import br.com.tokiomarine.arquitetura.smsservice.jackson.PhoneNumberDeserializer;
import lombok.Data;

@Data
public class BlacklistFilterDTO {
	@JsonDeserialize(using = PhoneNumberDeserializer.class)
	private String number;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdAt;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdBeforeAt;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime createdAfterAt;

}
