package br.com.tokiomarine.arquitetura.smsservice.provider.tww;

import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;

public class TWWException extends Exception {

	private static final long serialVersionUID = 1L;

	private SmsServerErrors error;

	public TWWException() {
		super();
	}

	public TWWException(String message, Throwable cause) {
		super(message, cause);
	}

	public TWWException(String message) {
		super(message);
	}

	public TWWException(SmsServerErrors error) {
		this.error = error;
	}

	public SmsServerErrors getError() {
		return error == null ? SmsServerErrors.RESOURCE_NOT_FOUND_PROVIDER : error;
	}

}
