package br.com.tokiomarine.arquitetura.smsservice.scheduling;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageReply;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.service.MessageReplyService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ConditionalOnProperty(prefix = "app", name = "scheduling.replies.enabled", havingValue = "true")
public class MessageReplyScheduledTasks {

	private static final String TIME_ZONE = "America/Sao_Paulo";

	private MessageReplyService messageReplyService;

	public MessageReplyScheduledTasks(MessageReplyService messageReplyService) {
		this.messageReplyService = messageReplyService;
	}

	@Scheduled(fixedRate = 1000, initialDelay = 5000)
	public void synchronizeMessageReplies() {
		MessageReply reply = messageReplyService.findAndModifyByProcessed();
		if (reply == null) {
			return;
		}

		messageReplyService.synchronizeMessageReply(reply);
	}

	@Scheduled(fixedDelayString = "${app.scheduling.replies.tww.fixed-delay}", initialDelay = 5000)
	public void fetchRepliesFromProviderTww() {
		log.debug("Buscando repostas de mensagem na TWW");
		messageReplyService.fetchMessageReplies(Provider.TWW);
	}
	
	@Scheduled(cron = "0 0 1 ? * *", zone = TIME_ZONE)
	public void purgingProcessedMessageReply() {
		messageReplyService.findAllAndRemoveByProcessed();
	}
}
