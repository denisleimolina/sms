package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class KindDTO {
	private String id;
}
