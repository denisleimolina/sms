package br.com.tokiomarine.arquitetura.smsservice.provider.directone;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.TokenIntegration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientResponseException;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.tokiomarine.arquitetura.smsservice.config.AppProperties;
import br.com.tokiomarine.arquitetura.smsservice.domain.Message;
import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;
import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;
import br.com.tokiomarine.arquitetura.smsservice.provider.MessageSender;
import br.com.tokiomarine.arquitetura.smsservice.provider.ProviderException;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.client.DirectOneRestClient;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.CommunicationNewDTO;
import br.com.tokiomarine.arquitetura.smsservice.provider.directone.dtoIntegration.builder.CommunicationBuilder;
import br.com.tokiomarine.arquitetura.smsservice.strategy.ProviderStrategy;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ProviderStrategy(name = Provider.DIRECT_ONE)
public class DirectOneMessageSenderIntegration implements MessageSender {

	private DirectOneRestClient restClient;

	private AppProperties properties;

	private ObjectMapper mapper;

	public DirectOneMessageSenderIntegration(DirectOneRestClient restClient, AppProperties properties, ObjectMapper mapper) {
		this.restClient = restClient;
		this.properties = properties;
		this.mapper = mapper;
	}

	@Override
	public void send(Message message) throws ProviderException {
		log.info("[{}] Enviando mensagem [id={}]", message.getProvider(), message.getId());

		CommunicationNewDTO communication = new CommunicationBuilder() // @formatter:off
				.withId(properties.getDirectOne().getCommunicationId())
				.withCustomer(message.getTo(), message.getBody(), message.getId())
				.build();// @formatter:on
				
		sendNewSMS(message, communication);
	}

	@Override
	public void synchronize(Message message) throws ProviderException {
	}

	@Override
	public void schedule(Message message) throws ProviderException {
		log.info("[{}] Enviando mensagem agendada [id={}]", message.getProvider(), message.getId());

		CommunicationNewDTO communication = new CommunicationBuilder() // @formatter:off
				.withId(properties.getDirectOne().getCommunicationId())
				.withCustomer(message.getTo(), message.getBody(), message.getId())
				.build();// @formatter:on

		sendNewSMS(message, communication);
	}

	private void sendNewSMS(Message message, CommunicationNewDTO communication) throws ProviderException {
		try {
			message.addTrace("bodyMessage", mapper.writeValueAsString(communication));

			ResponseEntity<TokenIntegration> responseEntity = restClient.sendNewSMS(communication);
			
			message.addTrace("statusCodeMessage", responseEntity.getStatusCodeValue());
		} catch (RestClientResponseException e) {
			int statusCode = e.getRawStatusCode();
			message.addTrace("statusCodeMessageError", statusCode);
			message.addTrace("bodyMessageError", e.getResponseBodyAsString());
			throw new ProviderException(errorResolver(statusCode), message, e);
		} catch (Exception e) {
			message.addTrace("messageError", e.getMessage());
			throw new ProviderException(SmsServerErrors.SERVICE_UNAVAILABLE, message, e);
		}
	}
	
	
	private SmsServerErrors errorResolver(int statusCode) {
		if (statusCode == BAD_REQUEST.value()) {
			return SmsServerErrors.BAD_REQUEST_PROVIDER;
		}
		return SmsServerErrors.SERVICE_UNAVAILABLE_PROVIDER;
	}

}
