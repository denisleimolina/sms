package br.com.tokiomarine.arquitetura.smsservice.strategy;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import br.com.tokiomarine.arquitetura.smsservice.domain.Provider;

@Component
public class ProviderStrategyFactory {

	private ApplicationContext applicationContext;

	@Autowired
	public ProviderStrategyFactory(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public <T> T getStrategy(Class<T> strategyType, Provider provider) {
		Map<String, T> beans = applicationContext.getBeansOfType(strategyType);

		for (T strategy : beans.values()) {
			ProviderStrategy annotation = AnnotationUtils.findAnnotation(strategy.getClass(), ProviderStrategy.class);
			if (annotation.name().equals(provider)) {
				return strategy;
			}
		}

		return null;
	}

}
