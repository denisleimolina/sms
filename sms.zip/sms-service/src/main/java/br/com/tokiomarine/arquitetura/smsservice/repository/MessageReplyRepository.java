package br.com.tokiomarine.arquitetura.smsservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.tokiomarine.arquitetura.smsservice.domain.MessageReply;

public interface MessageReplyRepository extends MongoRepository<MessageReply, String> {

}