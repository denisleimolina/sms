package br.com.tokiomarine.arquitetura.smsservice.web.rest.errors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceAlreadyExistsException;
import br.com.tokiomarine.arquitetura.smsservice.exception.BlacklistException;
import br.com.tokiomarine.arquitetura.smsservice.exception.ResourceNotFoundException;
import br.com.tokiomarine.arquitetura.smsservice.exception.SmsServerErrors;
import br.com.tokiomarine.arquitetura.smsservice.provider.ProviderException;

@RestControllerAdvice
public class RestExceptionHandler {

	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDTO handleConstraintViolationException(ConstraintViolationException ex, HttpServletRequest request) {
		// @formatter:off		
		ErrorDTO details = ErrorDTO.builder()
				.serverError(SmsServerErrors.VALIDATION_FAILED)
				.path(request.getRequestURI())
				.build();
		// @formatter:on

		ex.getConstraintViolations().forEach(v -> details.addViolation(v.getPropertyPath().toString(), v.getMessage()));

		return details;
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDTO handleMethodArgumentNotValidException(MethodArgumentNotValidException ex,
			HttpServletRequest request) {
		// @formatter:off		
		ErrorDTO details = ErrorDTO.builder()
				.serverError(SmsServerErrors.VALIDATION_FAILED)
				.path(request.getRequestURI())
				.build();
		// @formatter:on

		ex.getBindingResult().getGlobalErrors().forEach(e -> details.addViolation(e.getObjectName(), e.getDefaultMessage()));

		ex.getBindingResult().getFieldErrors().forEach(e -> details.addViolation(e.getField(), e.getDefaultMessage()));

		return details;
	}
	
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorDTO handleResourceNotFoundException(ResourceNotFoundException ex, HttpServletRequest request) {
		// @formatter:off		
		return ErrorDTO.builder()
				.serverError(SmsServerErrors.RESOURCE_NOT_FOUND)
				.path(request.getRequestURI())
				.build();
		// @formatter:on
	}
	
	@ExceptionHandler(ResourceAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ErrorDTO handleResourceAlreadyExistsException(ResourceAlreadyExistsException ex, HttpServletRequest request) {
		// @formatter:off		
		return ErrorDTO.builder()
				.serverError(SmsServerErrors.RESOURCE_ALREADY_EXISTS)
				.path(request.getRequestURI())
				.build();
		// @formatter:on
	}
	
	@ExceptionHandler(BlacklistException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorDTO handleResourceInBlacklistException(BlacklistException ex, HttpServletRequest request) {
		// @formatter:off		
		return ErrorDTO.builder()
				.serverError(SmsServerErrors.RESOURCE_IN_BLACKLIST)
				.path(request.getRequestURI())
				.resource(ex.getResource())
				.build();
		// @formatter:on
	}

	@ExceptionHandler(ProviderException.class)
	public ResponseEntity<ErrorDTO> handleProviderException(ProviderException e, HttpServletRequest request) {
		// @formatter:off		
		ErrorDTO details = ErrorDTO.builder()
				.serverError(e.getError())
				.path(request.getRequestURI())
				.resource(e.getResource())
				.trace(e.getCause().toString())
				.build();
			// @formatter:on
		
		return new ResponseEntity<>(details, new HttpHeaders(), e.getError().getStatus());
	}

}
