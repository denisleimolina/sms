package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import lombok.Data;

@Data
public class PhoneDTO {
	private String formattedNumber;
	private KindDTO kind;
	private Boolean preferential = false;
	private Boolean optOut = false;
}
