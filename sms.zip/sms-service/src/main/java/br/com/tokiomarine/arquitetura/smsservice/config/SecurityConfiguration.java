package br.com.tokiomarine.arquitetura.smsservice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.firewall.DefaultHttpFirewall;
import org.springframework.security.web.firewall.HttpFirewall;

@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	private UserDetailsService userDetailsService;

	private PasswordEncoder passwordEncoder;

	@Autowired
	public SecurityConfiguration(UserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
		this.userDetailsService = userDetailsService;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception { // @formatter:off	    
		http
			.csrf().disable()
			.authorizeRequests()
				.antMatchers(HttpMethod.OPTIONS,"/v1","/v1/*").permitAll()
				.antMatchers("/actuator","/actuator/**").permitAll()
				.antMatchers("/v1/webhook", "/v1/webhook/*").permitAll()
				.antMatchers("/v1/messages", "/v1/messages/*").hasAnyRole("ADMIN", "USER")
				.antMatchers("/v1/blacklist-items", "/v1/blacklist-items/*").hasAnyRole("ADMIN")
				.anyRequest().authenticated()
		.and()        
        	.httpBasic()
        .and()
        	.sessionManagement().disable();
	} // @formatter:on

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder);
	}

	@Override
	public void configure(WebSecurity web) throws Exception { //@formatter:off
		web.httpFirewall(allowUrlEncodedSlashHttpFirewall());
		
		web.ignoring().antMatchers(				
			"/v2/api-docs",
			"/configuration/ui", 
			"/swagger-resources/**", 
			"/configuration/**",
			"/swagger-ui.html", 
			"/webjars/**",
			"/hello",
			"/resources/**"
		);
	} // @formatter:on

	@Bean
	public HttpFirewall allowUrlEncodedSlashHttpFirewall() {
		DefaultHttpFirewall firewall = new DefaultHttpFirewall();
		firewall.setAllowUrlEncodedSlash(true);
		return firewall;
	}
}
