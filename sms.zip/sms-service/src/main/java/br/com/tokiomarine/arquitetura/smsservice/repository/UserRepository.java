package br.com.tokiomarine.arquitetura.smsservice.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import br.com.tokiomarine.arquitetura.smsservice.domain.User;

public interface UserRepository extends MongoRepository<User, String> {

	Optional<User> findByUsername(String username);
}