package br.com.tokiomarine.arquitetura.smsservice.provider.directone.dto;

import java.util.List;

import lombok.Data;

@Data
public class CustomerDTO {
	private String identification;
	private String name;
	private List<PhoneDTO> phones;

}
