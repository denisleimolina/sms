package br.com.tokiomarine.arquitetura.smsservice;

import org.junit.Test;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class TwilioTest {

	public static final String ACCOUNT_SID = "AC670bd250e2b4c200366ce30c2b9136b2";
	public static final String AUTH_TOKEN = "72fda7a5fdab587896431e48b4f35373";

	@Test
	public void sendingSMS() {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		Message message = Message
				.creator(new PhoneNumber("+5511982923600"), new PhoneNumber("+12564190467"), "Tokio testing...")
				.create();

		System.out.println(message.getSid());
	}

}
